import React, { useState } from 'react';
import { TREE_TYPES_LIST } from '../../data/treeData';
import { TreeTypeItem } from '../../types';
import { TreeSvg, VisualNode, VisualEdge } from './TreeSvg';
import { CheckCircle2, ShieldCheck } from 'lucide-react';

interface TreeTypesVisualizerProps {
  isDarkMode: boolean;
}

export const TreeTypesVisualizer: React.FC<TreeTypesVisualizerProps> = ({ isDarkMode }) => {
  const [selectedTypeId, setSelectedTypeId] = useState<string>('strictly');

  const selectedType: TreeTypeItem =
    TREE_TYPES_LIST.find((t) => t.id === selectedTypeId) || TREE_TYPES_LIST[0];

  // Helper to generate nodes and edges for each tree type
  const getTreeData = () => {
    switch (selectedTypeId) {
      case 'strictly': {
        const nodes: VisualNode[] = [
          { id: '10', value: 10, x: 325, y: 55, isRoot: true, subLabel: '2 Children', highlight: true },
          { id: '5', value: 5, x: 200, y: 170, subLabel: '0 Ch (Leaf)', isLeaf: true, highlightColor: 'emerald', highlight: true },
          { id: '15', value: 15, x: 450, y: 170, subLabel: '0 Ch (Leaf)', isLeaf: true, highlightColor: 'emerald', highlight: true }
        ];
        const edges: VisualEdge[] = [
          { fromId: '10', toId: '5', fromX: 325, fromY: 55, toX: 200, toY: 170 },
          { fromId: '10', toId: '15', fromX: 325, fromY: 55, toX: 450, toY: 170 }
        ];
        return {
          nodes,
          edges,
          description: 'Strictly Binary Tree: Every node has either 0 or 2 children. Root (10) has 2 children; Leaves (5, 15) have 0 children.'
        };
      }

      case 'full': {
        const nodes: VisualNode[] = [
          { id: '10', value: 10, x: 325, y: 50, isRoot: true, subLabel: '2 Children', highlight: true },
          { id: '5', value: 5, x: 190, y: 140, subLabel: '2 Children', highlight: true },
          { id: '15', value: 15, x: 460, y: 140, subLabel: '2 Children', highlight: true },
          { id: '2', value: 2, x: 120, y: 235, subLabel: '0 Ch (Leaf)', isLeaf: true, highlightColor: 'emerald', highlight: true },
          { id: '7', value: 7, x: 260, y: 235, subLabel: '0 Ch (Leaf)', isLeaf: true, highlightColor: 'emerald', highlight: true },
          { id: '12', value: 12, x: 390, y: 235, subLabel: '0 Ch (Leaf)', isLeaf: true, highlightColor: 'emerald', highlight: true },
          { id: '18', value: 18, x: 530, y: 235, subLabel: '0 Ch (Leaf)', isLeaf: true, highlightColor: 'emerald', highlight: true }
        ];
        const edges: VisualEdge[] = [
          { fromId: '10', toId: '5', fromX: 325, fromY: 50, toX: 190, toY: 140 },
          { fromId: '10', toId: '15', fromX: 325, fromY: 50, toX: 460, toY: 140 },
          { fromId: '5', toId: '2', fromX: 190, fromY: 140, toX: 120, toY: 235 },
          { fromId: '5', toId: '7', fromX: 190, fromY: 140, toX: 260, toY: 235 },
          { fromId: '15', toId: '12', fromX: 460, fromY: 140, toX: 390, toY: 235 },
          { fromId: '15', toId: '18', fromX: 460, fromY: 140, toX: 530, toY: 235 }
        ];
        return {
          nodes,
          edges,
          description: 'Full Binary Tree: Every node has either 0 or 2 children. Every parent branches into both children.'
        };
      }

      case 'complete': {
        const nodes: VisualNode[] = [
          { id: '10', value: 10, x: 325, y: 50, isRoot: true, level: 0 },
          { id: '5', value: 5, x: 200, y: 140, level: 1 },
          { id: '15', value: 15, x: 450, y: 140, level: 1 },
          { id: '2', value: 2, x: 130, y: 235, level: 2, subLabel: 'Leftmost', isLeaf: true, highlightColor: 'emerald', highlight: true },
          { id: '7', value: 7, x: 270, y: 235, level: 2, isLeaf: true, highlightColor: 'emerald', highlight: true },
          { id: '12', value: 12, x: 380, y: 235, level: 2, subLabel: 'Filled Left', isLeaf: true, highlightColor: 'emerald', highlight: true }
        ];
        const edges: VisualEdge[] = [
          { fromId: '10', toId: '5', fromX: 325, fromY: 50, toX: 200, toY: 140 },
          { fromId: '10', toId: '15', fromX: 325, fromY: 50, toX: 450, toY: 140 },
          { fromId: '5', toId: '2', fromX: 200, fromY: 140, toX: 130, toY: 235 },
          { fromId: '5', toId: '7', fromX: 200, fromY: 140, toX: 270, toY: 235 },
          { fromId: '15', toId: '12', fromX: 450, fromY: 140, toX: 380, toY: 235 }
        ];
        return {
          nodes,
          edges,
          description: 'Complete Binary Tree: All levels are completely filled except the last level, where nodes (2, 7, 12) are packed as far left as possible.'
        };
      }

      case 'perfect': {
        const nodes: VisualNode[] = [
          { id: '10', value: 10, x: 325, y: 50, isRoot: true, level: 0 },
          { id: '5', value: 5, x: 190, y: 140, level: 1 },
          { id: '15', value: 15, x: 460, y: 140, level: 1 },
          { id: '2', value: 2, x: 120, y: 235, isLeaf: true, level: 2, subLabel: 'Level 2' },
          { id: '7', value: 7, x: 260, y: 235, isLeaf: true, level: 2, subLabel: 'Level 2' },
          { id: '12', value: 12, x: 390, y: 235, isLeaf: true, level: 2, subLabel: 'Level 2' },
          { id: '18', value: 18, x: 530, y: 235, isLeaf: true, level: 2, subLabel: 'Level 2' }
        ];
        const edges: VisualEdge[] = [
          { fromId: '10', toId: '5', fromX: 325, fromY: 50, toX: 190, toY: 140 },
          { fromId: '10', toId: '15', fromX: 325, fromY: 50, toX: 460, toY: 140 },
          { fromId: '5', toId: '2', fromX: 190, fromY: 140, toX: 120, toY: 235 },
          { fromId: '5', toId: '7', fromX: 190, fromY: 140, toX: 260, toY: 235 },
          { fromId: '15', toId: '12', fromX: 460, fromY: 140, toX: 390, toY: 235 },
          { fromId: '15', toId: '18', fromX: 460, fromY: 140, toX: 530, toY: 235 }
        ];
        return {
          nodes,
          edges,
          description: 'Perfect Binary Tree: Every internal node has 2 children and all 4 leaves (2, 7, 12, 18) are on the exact same level.'
        };
      }

      case 'degenerate': {
        const nodes: VisualNode[] = [
          { id: '10', value: 10, x: 450, y: 45, isRoot: true, subLabel: 'Right-Only', highlight: true, highlightColor: 'amber' },
          { id: '20', value: 20, x: 370, y: 115, subLabel: 'Right-Only', highlight: true, highlightColor: 'amber' },
          { id: '30', value: 30, x: 290, y: 185, subLabel: 'Right-Only', highlight: true, highlightColor: 'amber' },
          { id: '40', value: 40, x: 210, y: 255, subLabel: 'Leaf', isLeaf: true, highlight: true, highlightColor: 'emerald' }
        ];
        const edges: VisualEdge[] = [
          { fromId: '10', toId: '20', fromX: 450, fromY: 45, toX: 370, toY: 115 },
          { fromId: '20', toId: '30', fromX: 370, fromY: 115, toX: 290, toY: 185 },
          { fromId: '30', toId: '40', fromX: 290, fromY: 185, toX: 210, toY: 255 }
        ];
        return {
          nodes,
          edges,
          description: 'Degenerate Binary Tree: Each node has only 1 child, forming a single chain with height N-1.'
        };
      }

      case 'bst': {
        const nodes: VisualNode[] = [
          { id: '50', value: 50, x: 325, y: 50, isRoot: true, subLabel: 'Root (50)', highlight: true },
          { id: '30', value: 30, x: 190, y: 140, subLabel: '< 50 (Left)', highlightColor: 'emerald', highlight: true },
          { id: '70', value: 70, x: 460, y: 140, subLabel: '> 50 (Right)', highlightColor: 'indigo', highlight: true },
          { id: '20', value: 20, x: 120, y: 235, isLeaf: true, subLabel: '< 30', highlightColor: 'emerald', highlight: true },
          { id: '40', value: 40, x: 260, y: 235, isLeaf: true, subLabel: '> 30', highlightColor: 'emerald', highlight: true },
          { id: '60', value: 60, x: 390, y: 235, isLeaf: true, subLabel: '< 70', highlightColor: 'indigo', highlight: true },
          { id: '80', value: 80, x: 530, y: 235, isLeaf: true, subLabel: '> 70', highlightColor: 'indigo', highlight: true }
        ];
        const edges: VisualEdge[] = [
          { fromId: '50', toId: '30', fromX: 325, fromY: 50, toX: 190, toY: 140 },
          { fromId: '50', toId: '70', fromX: 325, fromY: 50, toX: 460, toY: 140 },
          { fromId: '30', toId: '20', fromX: 190, fromY: 140, toX: 120, toY: 235 },
          { fromId: '30', toId: '40', fromX: 190, fromY: 140, toX: 260, toY: 235 },
          { fromId: '70', toId: '60', fromX: 460, fromY: 140, toX: 390, toY: 235 },
          { fromId: '70', toId: '80', fromX: 460, fromY: 140, toX: 530, toY: 235 }
        ];
        return {
          nodes,
          edges,
          description: 'Binary Search Tree (BST): Left Subtree (< 50) and Right Subtree (> 50) for fast O(log N) searching.'
        };
      }

      default:
        return { nodes: [], edges: [], description: '' };
    }
  };

  const { nodes, edges, description } = getTreeData();

  return (
    <div className="space-y-6">
      {/* Type Selector Tabs */}
      <div>
        <div className="text-xs font-semibold uppercase tracking-wider mb-2.5 opacity-75">
          Select Tree Type to Inspect:
        </div>
        <div className="flex flex-wrap gap-2">
          {TREE_TYPES_LIST.map((type) => {
            const isSelected = type.id === selectedTypeId;
            return (
              <button
                key={type.id}
                onClick={() => setSelectedTypeId(type.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all duration-200 cursor-pointer ${
                  isSelected
                    ? isDarkMode
                      ? 'bg-violet-600 text-white shadow-md shadow-violet-900/40 ring-2 ring-violet-400'
                      : 'bg-violet-600 text-white shadow-md shadow-violet-200 ring-2 ring-violet-500'
                    : isDarkMode
                    ? 'bg-[#1e1533] text-purple-200 hover:bg-[#281c44] border border-purple-900/40'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
                }`}
              >
                {type.name}
              </button>
            );
          })}
        </div>
      </div>

      {/* SVG Canvas Container */}
      <div className={`p-4 rounded-xl border transition-colors ${
        isDarkMode ? 'bg-[#150f24] border-purple-900/40' : 'bg-slate-50 border-slate-200'
      }`}>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-violet-400" />
            <span className="text-sm font-bold text-violet-400">
              Visual Structure: {selectedType.name}
            </span>
          </div>
          <span className="text-xs opacity-60">
            Interactive Tree Topology
          </span>
        </div>

        <TreeSvg
          nodes={nodes}
          edges={edges}
          isDarkMode={isDarkMode}
          height={320}
        />

        <div className={`mt-2 p-2.5 rounded-lg text-xs text-center font-medium ${
          isDarkMode ? 'bg-[#1c1330] text-purple-200' : 'bg-violet-50 text-violet-900'
        }`}>
          {description}
        </div>
      </div>

      {/* Rule Verification Card */}
      <div className={`p-5 rounded-xl border ${
        isDarkMode ? 'bg-[#171129] border-purple-900/50 text-purple-100' : 'bg-white border-slate-200 text-slate-800'
      }`}>
        <h4 className="text-base font-bold text-violet-400 mb-2">
          {selectedType.name} Specifications
        </h4>
        <p className="text-sm leading-relaxed mb-4">
          {selectedType.definition}
        </p>

        <div className={`p-3 rounded-lg mb-4 text-xs font-semibold ${
          isDarkMode ? 'bg-[#22163d] text-violet-300 border border-purple-800/40' : 'bg-violet-50 text-violet-900 border border-violet-200'
        }`}>
          Core Rule: {selectedType.rule}
        </div>

        <div className="space-y-2">
          <div className="text-xs font-bold uppercase tracking-wider text-violet-400">
            Key Properties:
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {selectedType.properties.map((prop, i) => (
              <div
                key={i}
                className={`p-2.5 rounded-lg text-xs flex items-start gap-2 ${
                  isDarkMode ? 'bg-[#1e1533] border border-purple-900/30' : 'bg-slate-50 border border-slate-200'
                }`}
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-violet-400 shrink-0 mt-0.5" />
                <span>{prop}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
