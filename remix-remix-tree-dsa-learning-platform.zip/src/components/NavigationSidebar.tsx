import React from 'react';
import { NavItem, TopicId } from '../types';
import {
  Home,
  BookOpen,
  Eye,
  Gamepad2,
  HelpCircle,
  TrendingUp,
  Menu,
  Sun,
  Moon,
  X,
  GitBranch
} from 'lucide-react';

interface NavigationSidebarProps {
  currentNav: NavItem;
  onSelectNav: (nav: NavItem) => void;
  isOpen: boolean;
  onToggleOpen: () => void;
  onClose: () => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
  completedTopics?: TopicId[];
  quizScore?: { score: number; total: number } | null;
}

export const NavigationSidebar: React.FC<NavigationSidebarProps> = ({
  currentNav,
  onSelectNav,
  isOpen,
  onToggleOpen,
  onClose,
  isDarkMode,
  onToggleTheme,
  completedTopics = [],
  quizScore = null
}) => {
  const navItems: { id: NavItem; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'home', label: 'Overview', icon: Home },
    { id: 'learn', label: 'Learn', icon: BookOpen },
    { id: 'visualize', label: 'Visualize', icon: Eye },
    { id: 'game', label: 'Game', icon: Gamepad2 },
    { id: 'quiz', label: 'Quiz', icon: HelpCircle },
    { id: 'progress', label: 'Progress', icon: TrendingUp }
  ];

  const getNavBadge = (id: NavItem): string => {
    switch (id) {
      case 'home':
        return '1/1';
      case 'learn':
        return `${completedTopics.length}/6`;
      case 'visualize':
        return '0/5';
      case 'game':
        return '0/5';
      case 'quiz':
        return quizScore ? `${quizScore.score}/${quizScore.total}` : '0/10';
      case 'progress':
        return `${Math.round((completedTopics.length / 6) * 100)}%`;
      default:
        return '';
    }
  };

  const handleNavClick = (id: NavItem) => {
    onSelectNav(id);
    if (window.innerWidth < 768) {
      onClose();
    }
  };

  return (
    <>
      {/* Mobile Backdrop (when sidebar is open on small screens) */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-black/60 z-40 md:hidden backdrop-blur-xs transition-opacity"
        />
      )}

      {/* Main Sidebar Container (Either full w-64 when open, or completely hidden when closed) */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-64 flex flex-col transition-transform duration-300 ease-in-out border-r ${
          isDarkMode
            ? 'bg-[#090d16] border-violet-950/60 text-slate-200 shadow-2xl shadow-violet-950/40'
            : 'bg-white border-slate-200 text-slate-800 shadow-xl'
        } ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Header with Project Logo, Title & Close/Toggle */}
        <div
          className={`h-16 flex items-center justify-between px-4 border-b ${
            isDarkMode ? 'border-violet-950/60' : 'border-slate-100'
          }`}
        >
          <div className="flex items-center gap-2.5 overflow-hidden">
            <div
              className={`w-8 h-8 rounded-xl flex items-center justify-center text-white shrink-0 shadow-md ${
                isDarkMode ? 'bg-violet-600 shadow-violet-900/50' : 'bg-indigo-600 shadow-indigo-200'
              }`}
            >
              <GitBranch className="w-4 h-4" />
            </div>
            <div className="flex flex-col">
              <span
                className={`font-bold text-sm tracking-tight leading-tight ${
                  isDarkMode ? 'text-violet-300' : 'text-indigo-900'
                }`}
              >
                TREE DSA
              </span>
              <span className="text-[10px] opacity-60 font-medium tracking-wide">
                Interactive Course
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {/* Toggle / Close Button */}
            <button
              id="sidebar-toggle-btn"
              onClick={onToggleOpen}
              title="Close Sidebar"
              className={`p-2 rounded-xl transition-all cursor-pointer ${
                isDarkMode
                  ? 'hover:bg-[#151c2e] text-slate-400 hover:text-white'
                  : 'hover:bg-slate-100 text-slate-600 hover:text-slate-900'
              }`}
            >
              <X className="w-5 h-5 hidden md:block" />
              <X className="w-5 h-5 md:hidden" />
            </button>
          </div>
        </div>

        {/* Navigation Items List */}
        <nav className="flex-1 py-4 px-3 space-y-1.5 overflow-y-auto">
          <div className="px-3 py-1 text-[11px] font-semibold tracking-wider uppercase opacity-40">
            Navigation Menu
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentNav === item.id;

            return (
              <button
                key={item.id}
                id={`nav-item-${item.id}`}
                onClick={() => handleNavClick(item.id)}
                className={`group w-full flex items-center gap-3 px-3.5 py-3 rounded-xl font-semibold text-sm transition-all duration-200 cursor-pointer justify-start ${
                  isActive
                    ? isDarkMode
                      ? 'bg-violet-600 text-white shadow-lg shadow-violet-950/70 font-bold ring-1 ring-violet-400/30'
                      : 'bg-indigo-600 text-white shadow-md shadow-indigo-200 font-bold'
                    : isDarkMode
                    ? 'text-slate-300 hover:bg-[#131b2e] hover:text-white'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <Icon
                  className={`w-5 h-5 shrink-0 ${
                    isActive
                      ? 'text-white'
                      : isDarkMode
                      ? 'text-violet-400'
                      : 'text-indigo-600'
                  }`}
                />
                <span className="truncate">{item.label}</span>
                <span
                  className={`ml-auto text-[11px] font-mono font-bold px-2 py-0.5 rounded-full transition-opacity duration-200 opacity-0 group-hover:opacity-100 ${
                    isActive
                      ? 'bg-white/20 text-white border border-white/30'
                      : isDarkMode
                      ? 'bg-violet-950/80 text-violet-300 border border-violet-700/50'
                      : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                  } shrink-0`}
                >
                  {getNavBadge(item.id)}
                </span>
              </button>
            );
          })}
        </nav>

        {/* Footer with Theme Switcher */}
        <div
          className={`p-3 border-t ${
            isDarkMode ? 'border-violet-950/60' : 'border-slate-100'
          }`}
        >
          <button
            id="theme-toggle-btn"
            onClick={onToggleTheme}
            title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer justify-start ${
              isDarkMode
                ? 'bg-[#101626] text-slate-300 hover:bg-[#161f36] border border-violet-950/70'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            {isDarkMode ? (
              <>
                <Sun className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Light Mode</span>
              </>
            ) : (
              <>
                <Moon className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>Dark Mode (Violet)</span>
              </>
            )}
          </button>
        </div>
      </aside>
    </>
  );
};

