import React, { useState } from 'react';
import { TreeSvg, VisualNode, VisualEdge } from '../visualizer/TreeSvg';
import { Plus, Search, Trash2, RotateCcw, Sparkles, Terminal, Play } from 'lucide-react';

interface PracticeViewProps {
  isDarkMode: boolean;
}

interface BSTNode {
  value: number;
  left: BSTNode | null;
  right: BSTNode | null;
}

export const PracticeView: React.FC<PracticeViewProps> = ({ isDarkMode }) => {
  // Tree state represented as BST
  const [treeValues, setTreeValues] = useState<number[]>([50, 30, 70, 20, 40, 60, 80]);
  const [inputValue, setInputValue] = useState<string>('');
  const [searchTarget, setSearchTarget] = useState<string>('');
  const [deleteTarget, setDeleteTarget] = useState<string>('');
  const [actionLog, setActionLog] = useState<string>('Welcome to the Interactive Tree Workbench. Insert, search, or delete nodes to experiment with BST structures.');
  const [searchPath, setSearchPath] = useState<number[]>([]);
  const [activeNodeVal, setActiveNodeVal] = useState<number | null>(null);

  // Helper to build BST from array of values
  const insertIntoBst = (root: BSTNode | null, val: number): BSTNode => {
    if (!root) return { value: val, left: null, right: null };
    if (val < root.value) {
      root.left = insertIntoBst(root.left, val);
    } else if (val > root.value) {
      root.right = insertIntoBst(root.right, val);
    }
    return root;
  };

  const deleteFromBst = (root: BSTNode | null, val: number): BSTNode | null => {
    if (!root) return null;
    if (val < root.value) {
      root.left = deleteFromBst(root.left, val);
    } else if (val > root.value) {
      root.right = deleteFromBst(root.right, val);
    } else {
      // Node found
      if (!root.left && !root.right) return null; // Case 1: Leaf
      if (!root.left) return root.right; // Case 2: One child (right)
      if (!root.right) return root.left; // Case 2: One child (left)

      // Case 3: Two children -> Find min in right subtree (In-order successor)
      let succ = root.right;
      while (succ.left) {
        succ = succ.left;
      }
      root.value = succ.value;
      root.right = deleteFromBst(root.right, succ.value);
    }
    return root;
  };

  // Convert tree into visual layout
  const buildVisualTree = () => {
    let bstRoot: BSTNode | null = null;
    treeValues.forEach((val) => {
      bstRoot = insertIntoBst(bstRoot, val);
    });

    const nodes: VisualNode[] = [];
    const edges: VisualEdge[] = [];

    const layoutSubtree = (node: BSTNode | null, x: number, y: number, spread: number, level: number, parentId?: number) => {
      if (!node) return;

      const isRoot = level === 0;
      const isLeaf = !node.left && !node.right;
      const isHighlighted = activeNodeVal === node.value;
      const isFoundInSearch = searchPath[searchPath.length - 1] === node.value;

      nodes.push({
        id: node.value,
        value: node.value,
        x,
        y,
        isRoot,
        isLeaf,
        level,
        highlight: isHighlighted || isFoundInSearch,
        highlightColor: isFoundInSearch ? 'emerald' : isHighlighted ? 'violet' : undefined,
        tag: isFoundInSearch ? 'Found' : undefined
      });

      if (parentId !== undefined) {
        const parentNode = nodes.find((n) => n.id === parentId);
        if (parentNode) {
          edges.push({
            fromId: parentId,
            toId: node.value,
            fromX: parentNode.x,
            fromY: parentNode.y,
            toX: x,
            toY: y,
            highlight: searchPath.includes(parentId) && searchPath.includes(node.value)
          });
        }
      }

      if (node.left) {
        layoutSubtree(node.left, x - spread, y + 80, spread * 0.52, level + 1, node.value);
      }
      if (node.right) {
        layoutSubtree(node.right, x + spread, y + 80, spread * 0.52, level + 1, node.value);
      }
    };

    layoutSubtree(bstRoot, 325, 55, 140, 0);

    return { nodes, edges };
  };

  const handleInsert = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const num = parseInt(inputValue.trim(), 10);
    if (isNaN(num)) return;

    if (treeValues.includes(num)) {
      setActionLog(`Value ${num} already exists in the BST (duplicates not allowed in standard BST).`);
      return;
    }

    if (treeValues.length >= 15) {
      setActionLog('Tree max capacity reached for visual clarity (15 nodes). Try deleting a node first.');
      return;
    }

    setTreeValues([...treeValues, num]);
    setActiveNodeVal(num);
    setSearchPath([]);
    setActionLog(`Inserted ${num} into BST. Traversed tree to maintain Left < Root < Right ordering.`);
    setInputValue('');
  };

  const handleSearch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const num = parseInt(searchTarget.trim(), 10);
    if (isNaN(num)) return;

    // Simulate search path
    let bstRoot: BSTNode | null = null;
    treeValues.forEach((val) => {
      bstRoot = insertIntoBst(bstRoot, val);
    });

    const path: number[] = [];
    let curr: BSTNode | null = bstRoot;
    let found = false;

    while (curr) {
      path.push(curr.value);
      if (curr.value === num) {
        found = true;
        break;
      }
      if (num < curr.value) {
        curr = curr.left;
      } else {
        curr = curr.right;
      }
    }

    setSearchPath(path);
    setActiveNodeVal(found ? num : null);

    if (found) {
      setActionLog(`Searching for ${num}: Found! Path traversed: ${path.join(' → ')} (${path.length} comparisons).`);
    } else {
      setActionLog(`Searching for ${num}: Not found. Path checked: ${path.join(' → ')} (reached null).`);
    }
  };

  const handleDelete = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const num = parseInt(deleteTarget.trim(), 10);
    if (isNaN(num)) return;

    if (!treeValues.includes(num)) {
      setActionLog(`Cannot delete ${num}: Value does not exist in the BST.`);
      return;
    }

    let bstRoot: BSTNode | null = null;
    treeValues.forEach((val) => {
      bstRoot = insertIntoBst(bstRoot, val);
    });

    const updatedRoot = deleteFromBst(bstRoot, num);

    // Reconstruct array via in-order
    const updatedValues: number[] = [];
    const inorder = (node: BSTNode | null) => {
      if (!node) return;
      inorder(node.left);
      updatedValues.push(node.value);
      inorder(node.right);
    };
    inorder(updatedRoot);

    setTreeValues(updatedValues);
    setSearchPath([]);
    setActiveNodeVal(null);
    setActionLog(`Deleted ${num} from BST and re-linked child pointers.`);
    setDeleteTarget('');
  };

  const handleReset = () => {
    setTreeValues([50, 30, 70, 20, 40, 60, 80]);
    setSearchPath([]);
    setActiveNodeVal(null);
    setActionLog('Reset tree to default balanced 3-level BST [50, 30, 70, 20, 40, 60, 80].');
  };

  const { nodes, edges } = buildVisualTree();

  return (
    <div className="max-w-4xl mx-auto space-y-6 py-2">
      {/* Header */}
      <div className={`p-6 rounded-2xl border ${
        isDarkMode ? 'bg-[#160f29] border-purple-900/50 text-purple-100' : 'bg-white border-slate-200 text-slate-900'
      }`}>
        <div className="flex items-center gap-2 text-violet-400 font-bold text-xs uppercase tracking-wider mb-2">
          <Terminal className="w-4 h-4" />
          <span>Interactive Practice Workbench</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-violet-400">
          Tree Sandbox & BST Operations
        </h1>
        <p className="text-xs sm:text-sm mt-1.5 opacity-80 leading-relaxed">
          Experiment with real-time insertions, searches, and deletions on an interactive Binary Search Tree canvas.
        </p>
      </div>

      {/* Interactive Controls Bar */}
      <div className={`p-5 rounded-2xl border space-y-4 ${
        isDarkMode ? 'bg-[#150f24] border-purple-900/40' : 'bg-white border-slate-200'
      }`}>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Insert Form */}
          <form onSubmit={handleInsert} className="flex gap-2">
            <input
              type="number"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Value to Insert"
              className={`w-full px-3 py-2 rounded-xl text-xs font-mono border focus:outline-none focus:ring-2 focus:ring-violet-500 ${
                isDarkMode ? 'bg-[#1e1533] border-purple-900/50 text-purple-100 placeholder-purple-400/50' : 'bg-slate-50 border-slate-200 text-slate-900'
              }`}
            />
            <button
              type="submit"
              className="px-3.5 py-2 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold transition-all shadow-md shrink-0 cursor-pointer flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              Insert
            </button>
          </form>

          {/* Search Form */}
          <form onSubmit={handleSearch} className="flex gap-2">
            <input
              type="number"
              value={searchTarget}
              onChange={(e) => setSearchTarget(e.target.value)}
              placeholder="Search Target"
              className={`w-full px-3 py-2 rounded-xl text-xs font-mono border focus:outline-none focus:ring-2 focus:ring-violet-500 ${
                isDarkMode ? 'bg-[#1e1533] border-purple-900/50 text-purple-100 placeholder-purple-400/50' : 'bg-slate-50 border-slate-200 text-slate-900'
              }`}
            />
            <button
              type="submit"
              className="px-3.5 py-2 rounded-xl bg-purple-700 hover:bg-purple-600 text-white text-xs font-bold transition-all shadow-md shrink-0 cursor-pointer flex items-center gap-1"
            >
              <Search className="w-3.5 h-3.5" />
              Search
            </button>
          </form>

          {/* Delete Form */}
          <form onSubmit={handleDelete} className="flex gap-2">
            <input
              type="number"
              value={deleteTarget}
              onChange={(e) => setDeleteTarget(e.target.value)}
              placeholder="Delete Node"
              className={`w-full px-3 py-2 rounded-xl text-xs font-mono border focus:outline-none focus:ring-2 focus:ring-rose-500 ${
                isDarkMode ? 'bg-[#1e1533] border-purple-900/50 text-purple-100 placeholder-purple-400/50' : 'bg-slate-50 border-slate-200 text-slate-900'
              }`}
            />
            <button
              type="submit"
              className="px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-all shadow-md shrink-0 cursor-pointer flex items-center gap-1"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Delete
            </button>
          </form>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-purple-900/20 text-xs">
          <span className="opacity-70 font-mono">
            Total Nodes: {treeValues.length}
          </span>
          <button
            onClick={handleReset}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border font-semibold transition-all cursor-pointer ${
              isDarkMode
                ? 'bg-[#1f1538] hover:bg-[#2b1c4f] text-purple-200 border-purple-900/40'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
            }`}
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset Tree
          </button>
        </div>
      </div>

      {/* SVG Canvas */}
      <div className={`p-4 rounded-2xl border ${
        isDarkMode ? 'bg-[#150f24] border-purple-900/40' : 'bg-slate-50 border-slate-200'
      }`}>
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold text-violet-400 uppercase tracking-wider">
            Live Tree Canvas
          </span>
          {searchPath.length > 0 && (
            <span className="text-xs font-mono font-bold text-emerald-400">
              Search Path: {searchPath.join(' → ')}
            </span>
          )}
        </div>

        <TreeSvg
          nodes={nodes}
          edges={edges}
          isDarkMode={isDarkMode}
          height={340}
        />
      </div>

      {/* Action Logs Box */}
      <div className={`p-4 rounded-xl border ${
        isDarkMode ? 'bg-[#18112b] border-purple-900/40 text-purple-200' : 'bg-white border-slate-200 text-slate-800'
      }`}>
        <div className="text-xs font-mono font-bold text-violet-400 mb-1 flex items-center gap-1.5">
          <Terminal className="w-3.5 h-3.5" />
          Workbench Operation Log:
        </div>
        <p className="text-xs font-mono leading-relaxed opacity-90">
          {actionLog}
        </p>
      </div>
    </div>
  );
};
