import React from 'react';
import { NavItem, TopicId } from '../../types';
import {
  Sparkles,
  Layers,
  Zap,
  Folder,
  Globe,
  Star,
  Search,
  Binary,
  PlusCircle,
  Activity,
  GitBranch,
  ArrowRight
} from 'lucide-react';

interface HomeViewProps {
  onNavigate: (nav: NavItem, topicId?: TopicId) => void;
  isDarkMode: boolean;
}

const RocketIllustration: React.FC<{ className?: string }> = ({ className = 'w-16 h-16 sm:w-20 sm:h-20' }) => (
  <svg
    viewBox="0 0 100 100"
    className={`${className} select-none shrink-0 drop-shadow-md`}
    aria-hidden="true"
  >
    <defs>
      {/* 3D White Fuselage Gradient */}
      <linearGradient id="rocketBodyGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#ffffff" />
        <stop offset="65%" stopColor="#f8fafc" />
        <stop offset="100%" stopColor="#cbd5e1" />
      </linearGradient>

      {/* Vibrant Purple/Violet Fin Gradient */}
      <linearGradient id="rocketVioletGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#c084fc" />
        <stop offset="50%" stopColor="#8b5cf6" />
        <stop offset="100%" stopColor="#6d28d9" />
      </linearGradient>

      {/* Porthole Window Cyan/Blue Glass */}
      <linearGradient id="windowGlassGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#38bdf8" />
        <stop offset="100%" stopColor="#6366f1" />
      </linearGradient>

      {/* Exhaust Flame Gradient */}
      <linearGradient id="rocketFlameGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#fef08a" />
        <stop offset="40%" stopColor="#f97316" />
        <stop offset="100%" stopColor="#ef4444" />
      </linearGradient>

      {/* Smoke Cloud Gradient */}
      <linearGradient id="smokeCloudGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#ffffff" />
        <stop offset="100%" stopColor="#e0e7ff" />
      </linearGradient>
    </defs>

    {/* Soft Puffy White & Light Smoke Clouds billowed beneath */}
    <g opacity="0.95">
      <circle cx="26" cy="76" r="14" fill="url(#smokeCloudGrad)" />
      <circle cx="42" cy="82" r="11" fill="url(#smokeCloudGrad)" />
      <circle cx="15" cy="82" r="9" fill="url(#smokeCloudGrad)" />
      <circle cx="32" cy="86" r="8" fill="#cbd5e1" opacity="0.7" />
    </g>

    {/* Colorful small accent sparkle details & stars */}
    <path d="M78 14 L80 18 L84 20 L80 22 L78 26 L76 22 L72 20 L76 18 Z" fill="#facc15" />
    <path d="M14 40 L15.5 43 L18.5 44.5 L15.5 46 L14 49 L12.5 46 L9.5 44.5 L12.5 43 Z" fill="#c084fc" />
    <circle cx="86" cy="36" r="2.2" fill="#38bdf8" />
    <circle cx="20" cy="22" r="1.5" fill="#f43f5e" />
    <circle cx="68" cy="8" r="1.5" fill="#facc15" />

    {/* Rocket Components */}
    <g transform="translate(6, -2)">
      {/* Propulsion Exhaust Flame */}
      <path
        d="M38 68 C34 77 30 85 34 89 C38 87 43 79 46 72 Z"
        fill="url(#rocketFlameGrad)"
      />
      <path
        d="M37 70 C35 75 33 79 36 82 C38 80 41 76 43 72 Z"
        fill="#fef08a"
      />

      {/* Thruster Nozzle */}
      <polygon points="36,62 48,70 44,74 32,66" fill="#334155" />

      {/* Left Fin (Purple / Violet) */}
      <path
        d="M36 52 L20 67 C20 67 25 73 34 68 L39 60 Z"
        fill="url(#rocketVioletGrad)"
      />

      {/* Right Fin (Purple / Violet) */}
      <path
        d="M52 36 L67 20 C67 20 73 25 68 34 L60 39 Z"
        fill="url(#rocketVioletGrad)"
      />

      {/* White Aerodynamic Rocket Fuselage */}
      <path
        d="M72 16 C60 16 38 34 34 62 L48 70 C74 64 90 40 72 16 Z"
        fill="url(#rocketBodyGrad)"
      />

      {/* Purple / Violet Nose Cone */}
      <path
        d="M72 16 C67 17 60 22 56 27 C63 31 71 39 75 46 C79 41 81 31 72 16 Z"
        fill="url(#rocketVioletGrad)"
      />

      {/* Center 3D Dorsal Fin Accent */}
      <polygon points="46,47 38,59 43,62 51,50" fill="#6d28d9" />

      {/* Circular Porthole Window with Purple Rim & Cyan Glass */}
      <circle cx="56" cy="42" r="8" fill="#4338ca" />
      <circle cx="56" cy="42" r="6.2" fill="url(#windowGlassGrad)" />
      <ellipse cx="54" cy="40" rx="3" ry="1.8" fill="#ffffff" opacity="0.8" transform="rotate(-30 54 40)" />
      <circle cx="58" cy="44" r="1" fill="#ffffff" opacity="0.75" />
    </g>
  </svg>
);

export const HomeView: React.FC<HomeViewProps> = ({ onNavigate, isDarkMode }) => {
  return (
    <div className="max-w-5xl mx-auto space-y-8 py-2">
      {/* ==================================================================== */}
      {/* HERO CARD                                                           */}
      {/* ==================================================================== */}
      <section
        id="home-hero-card"
        className={`relative overflow-hidden p-6 sm:p-8 md:p-10 rounded-3xl border transition-all duration-300 ${
          isDarkMode
            ? 'bg-[#0e1424] border-violet-900/40 text-slate-100 shadow-2xl shadow-violet-950/40'
            : 'bg-white border-slate-200 text-slate-900 shadow-xl shadow-slate-200/50'
        }`}
      >
        {isDarkMode && (
          <div className="absolute -top-24 -right-24 w-96 h-96 bg-violet-600/10 rounded-full blur-3xl pointer-events-none" />
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
          {/* Left Hero Content */}
          <div className="lg:col-span-7 space-y-4">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-bold tracking-wider uppercase border bg-violet-500/10 text-violet-400 border-violet-500/30">
              <Sparkles className="w-3.5 h-3.5" />
              <span>CHAPTER 1 • FOUNDATIONS</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight leading-tight text-balance">
              <span className={isDarkMode ? 'text-white' : 'text-slate-900'}>
                Non-Linear Hierarchical{' '}
              </span>
              <span className={isDarkMode ? 'text-violet-400' : 'text-indigo-600'}>
                Data Structures
              </span>
            </h1>

            <p className="text-sm sm:text-base opacity-80 leading-relaxed text-balance">
              Trees organize data in top-down levels rather than linear sequences. 
              Master the foundational hierarchy of roots, internal nodes, leaves, subtrees, 
              and logarithmic search efficiency.
            </p>
          </div>

          {/* Right Hero Graphic: Tree Illustration */}
          <div className="lg:col-span-5 flex justify-center">
            <div
              className={`w-full max-w-sm p-4 rounded-2xl border flex flex-col items-center justify-center ${
                isDarkMode
                  ? 'bg-[#090d18] border-violet-950/80'
                  : 'bg-slate-50 border-slate-200'
              }`}
            >
              {/* Responsive SVG Tree Illustration */}
              <svg viewBox="0 0 320 230" className="w-full h-auto select-none">
                <defs>
                  <linearGradient id="heroEdgeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor={isDarkMode ? '#8b5cf6' : '#6366f1'} />
                    <stop offset="100%" stopColor={isDarkMode ? '#6d28d9' : '#4f46e5'} />
                  </linearGradient>
                  <filter id="heroNodeGlow" x="-20%" y="-20%" width="140%" height="140%">
                    <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor={isDarkMode ? '#8b5cf6' : '#6366f1'} floodOpacity="0.4" />
                  </filter>
                </defs>

                {/* Level Guideline indicators */}
                <line x1="20" y1="40" x2="300" y2="40" stroke={isDarkMode ? '#1e293b' : '#e2e8f0'} strokeDasharray="3 3" strokeWidth="1" />
                <text x="25" y="32" fill={isDarkMode ? '#64748b' : '#94a3b8'} fontSize="8" fontFamily="monospace">Level 0 (Root)</text>

                <line x1="20" y1="115" x2="300" y2="115" stroke={isDarkMode ? '#1e293b' : '#e2e8f0'} strokeDasharray="3 3" strokeWidth="1" />
                <text x="25" y="107" fill={isDarkMode ? '#64748b' : '#94a3b8'} fontSize="8" fontFamily="monospace">Level 1 (Branch)</text>

                <line x1="20" y1="190" x2="300" y2="190" stroke={isDarkMode ? '#1e293b' : '#e2e8f0'} strokeDasharray="3 3" strokeWidth="1" />
                <text x="25" y="182" fill={isDarkMode ? '#64748b' : '#94a3b8'} fontSize="8" fontFamily="monospace">Level 2 (Leaves)</text>

                {/* Edges */}
                <line x1="160" y1="40" x2="95" y2="115" stroke="url(#heroEdgeGrad)" strokeWidth="2.5" strokeLinecap="round" />
                <line x1="160" y1="40" x2="225" y2="115" stroke="url(#heroEdgeGrad)" strokeWidth="2.5" strokeLinecap="round" />
                <line x1="95" y1="115" x2="60" y2="190" stroke="url(#heroEdgeGrad)" strokeWidth="2" strokeLinecap="round" />
                <line x1="95" y1="115" x2="130" y2="190" stroke="url(#heroEdgeGrad)" strokeWidth="2" strokeLinecap="round" />
                <line x1="225" y1="115" x2="190" y2="190" stroke="url(#heroEdgeGrad)" strokeWidth="2" strokeLinecap="round" />
                <line x1="225" y1="115" x2="260" y2="190" stroke="url(#heroEdgeGrad)" strokeWidth="2" strokeLinecap="round" />

                {/* Root Node */}
                <circle cx="160" cy="40" r="18" fill={isDarkMode ? '#7c3aed' : '#4f46e5'} filter="url(#heroNodeGlow)" stroke={isDarkMode ? '#c4b5fd' : '#ffffff'} strokeWidth="2" />
                <text x="160" y="44" fill="#ffffff" fontSize="11" fontWeight="bold" textAnchor="middle" dominantBaseline="middle">50</text>

                {/* Level 1 Nodes */}
                <circle cx="95" cy="115" r="15" fill={isDarkMode ? '#1e1b4b' : '#e0e7ff'} stroke={isDarkMode ? '#8b5cf6' : '#6366f1'} strokeWidth="2" />
                <text x="95" y="119" fill={isDarkMode ? '#e0e7ff' : '#1e1b4b'} fontSize="10" fontWeight="bold" textAnchor="middle" dominantBaseline="middle">30</text>

                <circle cx="225" cy="115" r="15" fill={isDarkMode ? '#1e1b4b' : '#e0e7ff'} stroke={isDarkMode ? '#8b5cf6' : '#6366f1'} strokeWidth="2" />
                <text x="225" y="119" fill={isDarkMode ? '#e0e7ff' : '#1e1b4b'} fontSize="10" fontWeight="bold" textAnchor="middle" dominantBaseline="middle">70</text>

                {/* Level 2 Leaves */}
                <circle cx="60" cy="190" r="13" fill={isDarkMode ? '#064e3b' : '#d1fae5'} stroke={isDarkMode ? '#10b981' : '#059669'} strokeWidth="1.5" />
                <text x="60" y="194" fill={isDarkMode ? '#a7f3d0' : '#065f46'} fontSize="9" fontWeight="bold" textAnchor="middle" dominantBaseline="middle">20</text>

                <circle cx="130" cy="190" r="13" fill={isDarkMode ? '#064e3b' : '#d1fae5'} stroke={isDarkMode ? '#10b981' : '#059669'} strokeWidth="1.5" />
                <text x="130" y="194" fill={isDarkMode ? '#a7f3d0' : '#065f46'} fontSize="9" fontWeight="bold" textAnchor="middle" dominantBaseline="middle">40</text>

                <circle cx="190" cy="190" r="13" fill={isDarkMode ? '#064e3b' : '#d1fae5'} stroke={isDarkMode ? '#10b981' : '#059669'} strokeWidth="1.5" />
                <text x="190" y="194" fill={isDarkMode ? '#a7f3d0' : '#065f46'} fontSize="9" fontWeight="bold" textAnchor="middle" dominantBaseline="middle">60</text>

                <circle cx="260" cy="190" r="13" fill={isDarkMode ? '#064e3b' : '#d1fae5'} stroke={isDarkMode ? '#10b981' : '#059669'} strokeWidth="1.5" />
                <text x="260" y="194" fill={isDarkMode ? '#a7f3d0' : '#065f46'} fontSize="9" fontWeight="bold" textAnchor="middle" dominantBaseline="middle">80</text>
              </svg>

              <div className="mt-2 text-[11px] font-mono opacity-60 text-center">
                Root: 50 | Leaves: [20, 40, 60, 80] | (N - 1) Edges Rule
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ==================================================================== */}
      {/* THREE INFORMATION CARDS                                              */}
      {/* ==================================================================== */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Card 1: Core Idea */}
        <div
          id="info-card-core-idea"
          onClick={() => onNavigate('visualize')}
          className={`p-6 rounded-2xl border transition-all duration-200 cursor-pointer ${
            isDarkMode
              ? 'bg-[#0e1424] border-violet-900/40 hover:border-violet-500/50'
              : 'bg-white border-slate-200 hover:border-indigo-400 shadow-sm'
          }`}
        >
          <div className="flex items-center gap-3 mb-3">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 border transition-all ${
              isDarkMode
                ? 'bg-violet-950/40 border-violet-500/50 text-violet-400 shadow-sm shadow-violet-500/20'
                : 'bg-violet-50 border-violet-200 text-violet-600'
            }`}>
              <Layers className="w-5 h-5" />
            </div>
            <h3 className={`text-base font-bold ${isDarkMode ? 'text-violet-300' : 'text-indigo-900'}`}>
              Core Idea
            </h3>
          </div>
          <p className="text-xs sm:text-sm opacity-80 leading-relaxed">
            Trees organize data hierarchically, where each node connects to its children.
          </p>
        </div>

        {/* Card 2: Important Concept */}
        <div
          id="info-card-important-concept"
          className={`p-6 rounded-2xl border transition-all duration-200 ${
            isDarkMode
              ? 'bg-[#0e1424] border-violet-900/40 hover:border-violet-500/50'
              : 'bg-white border-slate-200 hover:border-indigo-400 shadow-sm'
          }`}
        >
          <div className="flex items-center gap-3 mb-3">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 border transition-all ${
              isDarkMode
                ? 'bg-cyan-950/40 border-cyan-500/50 text-cyan-400 shadow-sm shadow-cyan-500/20'
                : 'bg-cyan-50 border-cyan-200 text-cyan-600'
            }`}>
              <GitBranch className="w-5 h-5" />
            </div>
            <h3 className={`text-base font-bold ${isDarkMode ? 'text-violet-300' : 'text-indigo-900'}`}>
              Important Concept
            </h3>
          </div>
          <p className="text-xs sm:text-sm opacity-80 leading-relaxed">
            Trees are non-linear structures with no cycles and a unique path between nodes.
          </p>
        </div>

        {/* Card 3: Main Challenge */}
        <div
          id="info-card-main-challenge"
          className={`p-6 rounded-2xl border transition-all duration-200 ${
            isDarkMode
              ? 'bg-[#0e1424] border-violet-900/40 hover:border-violet-500/50'
              : 'bg-white border-slate-200 hover:border-indigo-400 shadow-sm'
          }`}
        >
          <div className="flex items-center gap-3 mb-3">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 border transition-all ${
              isDarkMode
                ? 'bg-amber-950/40 border-amber-500/50 text-amber-400 shadow-sm shadow-amber-500/20'
                : 'bg-amber-50 border-amber-200 text-amber-600'
            }`}>
              <Zap className="w-5 h-5" />
            </div>
            <h3 className={`text-base font-bold ${isDarkMode ? 'text-violet-300' : 'text-indigo-900'}`}>
              Main Challenge
            </h3>
          </div>
          <p className="text-xs sm:text-sm opacity-80 leading-relaxed">
            Understand tree traversal and maintain efficient search performance.
          </p>
        </div>
      </section>

      {/* ==================================================================== */}
      {/* 1. THE MAIN IDEA                                                     */}
      {/* ==================================================================== */}
      <section
        id="section-the-main-idea"
        className={`p-6 sm:p-8 rounded-3xl border transition-all duration-200 ${
          isDarkMode
            ? 'bg-[#0e1424] border-violet-900/40 text-slate-100'
            : 'bg-white border-slate-200 text-slate-900 shadow-sm'
        }`}
      >
        <div className="flex items-center gap-3 mb-6">
          <div
            className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm shrink-0 ${
              isDarkMode
                ? 'bg-violet-600 text-white shadow-md shadow-violet-900/40'
                : 'bg-indigo-600 text-white shadow-md shadow-indigo-200'
            }`}
          >
            1
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight">
            1. The Main Idea
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Explanation Area */}
          <div className="lg:col-span-7 space-y-4">
            <p className="text-sm leading-relaxed opacity-90">
              A tree starts with a root node and grows into smaller connected nodes, just like branches of a real tree.
            </p>
          </div>

          {/* Visual Concept Area */}
          <div className="lg:col-span-5 flex justify-center">
            <div
              className={`w-full p-4 rounded-2xl border flex flex-col items-center justify-center ${
                isDarkMode ? 'bg-[#090d18] border-violet-950/80' : 'bg-slate-50 border-slate-200'
              }`}
            >
              <div className="text-[11px] font-bold tracking-wider uppercase text-violet-400 mb-2">
                Linear vs Hierarchical Concept
              </div>

              {/* Diagram */}
              <div className="w-full space-y-3 text-xs">
                {/* Linear */}
                <div className={`p-2.5 rounded-xl border flex items-center justify-between ${
                  isDarkMode ? 'bg-[#121929] border-violet-950/60' : 'bg-white border-slate-200'
                }`}>
                  <span className="text-[10px] font-bold uppercase opacity-60">Linear List</span>
                  <div className="flex items-center gap-1 font-mono text-[11px] font-bold">
                    <span className="px-1.5 py-0.5 rounded bg-slate-700/50">A</span> →
                    <span className="px-1.5 py-0.5 rounded bg-slate-700/50">B</span> →
                    <span className="px-1.5 py-0.5 rounded bg-slate-700/50">C</span> →
                    <span className="px-1.5 py-0.5 rounded bg-slate-700/50">D</span>
                  </div>
                </div>

                {/* Tree */}
                <div className={`p-2.5 rounded-xl border ${
                  isDarkMode ? 'bg-[#121929] border-violet-950/60' : 'bg-white border-slate-200'
                }`}>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[10px] font-bold uppercase text-violet-400">Tree Hierarchy</span>
                    <span className="text-[10px] font-mono text-emerald-400 font-bold">O(log N) Search</span>
                  </div>
                  <div className="flex flex-col items-center gap-1 font-mono text-[11px]">
                    <div className="px-2 py-0.5 rounded bg-violet-600 text-white font-bold">Root (A)</div>
                    <div className="flex items-center gap-6">
                      <div className="px-2 py-0.5 rounded bg-indigo-900/60 border border-indigo-500/40">Subtree B</div>
                      <div className="px-2 py-0.5 rounded bg-indigo-900/60 border border-indigo-500/40">Subtree C</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ==================================================================== */}
      {/* 2. CONCEPT ROADMAP                                                   */}
      {/* ==================================================================== */}
      <section
        id="section-concept-roadmap"
        className={`p-6 sm:p-8 rounded-3xl border transition-all duration-200 ${
          isDarkMode
            ? 'bg-[#0e1424] border-violet-900/40 text-slate-100'
            : 'bg-white border-slate-200 text-slate-900 shadow-sm'
        }`}
      >
        <div className="flex items-center justify-between gap-4 mb-8">
          <div className="flex items-center gap-3">
            <div
              className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm shrink-0 ${
                isDarkMode
                  ? 'bg-violet-600 text-white shadow-md shadow-violet-900/40'
                  : 'bg-indigo-600 text-white shadow-md shadow-indigo-200'
              }`}
            >
              2
            </div>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight">
              2. Concept Roadmap
            </h2>
          </div>

          <button
            onClick={() => onNavigate('learn')}
            className="text-xs font-bold text-violet-400 hover:text-violet-300 flex items-center gap-1 cursor-pointer"
          >
            <span>View All Topics</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Horizontal roadmap container with numbered steps, connecting line, circular icons */}
        <div className="relative">
          {/* Horizontal Connecting Line (visible on desktop) */}
          <div 
            className={`hidden lg:block absolute top-[38px] left-[40px] right-[40px] h-[2px] z-0 ${
              isDarkMode ? 'bg-violet-900/60' : 'bg-slate-200'
            }`} 
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-4 relative z-10">
            {[
              {
                num: '1',
                title: 'Tree Basics',
                sub: 'Non-linear hierarchy',
                topicId: 'basics' as TopicId,
                icon: Layers,
                colorDark: 'bg-violet-950/40 border-violet-500/50 text-violet-400 group-hover:border-violet-400 group-hover:text-violet-300 shadow-sm shadow-violet-500/20',
                colorLight: 'bg-violet-50 border-violet-200 text-violet-600 group-hover:border-violet-400 group-hover:text-violet-700',
                badgeDark: 'bg-violet-600 text-white ring-2 ring-[#090d18]',
                badgeLight: 'bg-violet-600 text-white ring-2 ring-slate-50'
              },
              {
                num: '2',
                title: 'Tree Terminology',
                sub: '13 core terms',
                topicId: 'terminology' as TopicId,
                icon: Binary,
                colorDark: 'bg-blue-950/40 border-blue-500/50 text-blue-400 group-hover:border-blue-400 group-hover:text-blue-300 shadow-sm shadow-blue-500/20',
                colorLight: 'bg-blue-50 border-blue-200 text-blue-600 group-hover:border-blue-400 group-hover:text-blue-700',
                badgeDark: 'bg-blue-600 text-white ring-2 ring-[#090d18]',
                badgeLight: 'bg-blue-600 text-white ring-2 ring-slate-50'
              },
              {
                num: '3',
                title: 'Types of Trees',
                sub: '7 classifications',
                topicId: 'types' as TopicId,
                icon: Search,
                colorDark: 'bg-cyan-950/40 border-cyan-500/50 text-cyan-400 group-hover:border-cyan-400 group-hover:text-cyan-300 shadow-sm shadow-cyan-500/20',
                colorLight: 'bg-cyan-50 border-cyan-200 text-cyan-600 group-hover:border-cyan-400 group-hover:text-cyan-700',
                badgeDark: 'bg-cyan-600 text-white ring-2 ring-[#090d18]',
                badgeLight: 'bg-cyan-600 text-white ring-2 ring-slate-50'
              },
              {
                num: '4',
                title: 'Binary Tree',
                sub: 'Pointers & memory',
                topicId: 'binary-tree' as TopicId,
                icon: PlusCircle,
                colorDark: 'bg-pink-950/40 border-pink-500/50 text-pink-400 group-hover:border-pink-400 group-hover:text-pink-300 shadow-sm shadow-pink-500/20',
                colorLight: 'bg-pink-50 border-pink-200 text-pink-600 group-hover:border-pink-400 group-hover:text-pink-700',
                badgeDark: 'bg-pink-600 text-white ring-2 ring-[#090d18]',
                badgeLight: 'bg-pink-600 text-white ring-2 ring-slate-50'
              },
              {
                num: '5',
                title: 'Tree Traversals',
                sub: 'Pre, In, Post, BFS',
                topicId: 'traversals' as TopicId,
                icon: Activity,
                colorDark: 'bg-amber-950/40 border-amber-500/50 text-amber-400 group-hover:border-amber-400 group-hover:text-amber-300 shadow-sm shadow-amber-500/20',
                colorLight: 'bg-amber-50 border-amber-200 text-amber-600 group-hover:border-amber-400 group-hover:text-amber-700',
                badgeDark: 'bg-amber-600 text-white ring-2 ring-[#090d18]',
                badgeLight: 'bg-amber-600 text-white ring-2 ring-slate-50'
              },
              {
                num: '6',
                title: 'Binary Search Tree',
                sub: 'Insert, Search, Delete',
                topicId: 'bst' as TopicId,
                icon: GitBranch,
                colorDark: 'bg-emerald-950/40 border-emerald-500/50 text-emerald-400 group-hover:border-emerald-400 group-hover:text-emerald-300 shadow-sm shadow-emerald-500/20',
                colorLight: 'bg-emerald-50 border-emerald-200 text-emerald-600 group-hover:border-emerald-400 group-hover:text-emerald-700',
                badgeDark: 'bg-emerald-600 text-white ring-2 ring-[#090d18]',
                badgeLight: 'bg-emerald-600 text-white ring-2 ring-slate-50'
              }
            ].map((step, idx) => {
              const IconComp = step.icon;
              return (
                <div
                  key={idx}
                  onClick={() => onNavigate('learn', step.topicId)}
                  className={`p-4 rounded-2xl border transition-all duration-200 cursor-pointer group hover:scale-[1.02] flex flex-col items-center text-center ${
                    isDarkMode
                      ? 'bg-[#090d18] border-violet-950/80 hover:border-violet-500/60'
                      : 'bg-slate-50 border-slate-200 hover:border-indigo-400'
                  }`}
                >
                  {/* Circular Icon */}
                  <div className="mb-3 flex flex-col items-center">
                    <div
                      className={`w-12 h-12 rounded-full flex items-center justify-center border transition-all duration-200 ${
                        isDarkMode ? step.colorDark : step.colorLight
                      }`}
                    >
                      <IconComp className="w-5 h-5 stroke-[1.75]" />
                    </div>
                  </div>

                  <h3 className={`text-xs font-bold leading-snug mb-1 ${
                    isDarkMode ? 'text-slate-100 group-hover:text-violet-300' : 'text-slate-900 group-hover:text-indigo-600'
                  }`}>
                    {step.title}
                  </h3>

                  <p className="text-[11px] opacity-60">
                    {step.sub}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ==================================================================== */}
      {/* 3. WHY TREES MATTER                                                  */}
      {/* ==================================================================== */}
      <section
        id="section-why-trees-matter"
        className={`p-6 sm:p-8 rounded-3xl border transition-all duration-200 ${
          isDarkMode
            ? 'bg-[#0e1424] border-violet-900/40 text-slate-100'
            : 'bg-white border-slate-200 text-slate-900 shadow-sm'
        }`}
      >
        <div className="flex items-center gap-3 mb-6">
          <div
            className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 border ${
              isDarkMode
                ? 'bg-violet-950/60 border-violet-500/50 text-violet-400 shadow-sm shadow-violet-500/20'
                : 'bg-violet-50 border-violet-200 text-violet-600'
            }`}
          >
            <Star className="w-4 h-4" />
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight">
            3. Why Trees Matter
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Card 1: Fast O(log n) Search */}
          <div
            className={`p-5 rounded-2xl border ${
              isDarkMode ? 'bg-[#090d18] border-violet-950/70' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-3 shrink-0 border transition-all ${
              isDarkMode
                ? 'bg-violet-950/40 border-violet-500/50 text-violet-400 shadow-sm shadow-violet-500/20'
                : 'bg-violet-50 border-violet-200 text-violet-600'
            }`}>
              <Zap className="w-5 h-5 stroke-[1.75]" />
            </div>
            <h3 className={`text-sm font-bold mb-1.5 ${isDarkMode ? 'text-violet-300' : 'text-indigo-900'}`}>
              Fast O(log n) Search
            </h3>
            <p className="text-xs opacity-80 leading-relaxed">
              Operating system directories, JSON nested trees, and browser HTML Document Object Models 
              are built natively as multi-way trees.
            </p>
          </div>

          {/* Card 2: Dynamic Organization */}
          <div
            className={`p-5 rounded-2xl border ${
              isDarkMode ? 'bg-[#090d18] border-violet-950/70' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-3 shrink-0 border transition-all ${
              isDarkMode
                ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-400 shadow-sm shadow-emerald-500/20'
                : 'bg-emerald-50 border-emerald-200 text-emerald-600'
            }`}>
              <Folder className="w-5 h-5 stroke-[1.75]" />
            </div>
            <h3 className={`text-sm font-bold mb-1.5 ${isDarkMode ? 'text-violet-300' : 'text-indigo-900'}`}>
              Dynamic Organization
            </h3>
            <p className="text-xs opacity-80 leading-relaxed">
              Database indexing structures (B-Trees, B+ Trees) and Binary Search Trees enable 
              lightning-fast searches across millions of records in O(log N) steps.
            </p>
          </div>

          {/* Card 3: Real-World Applications */}
          <div
            className={`p-5 rounded-2xl border ${
              isDarkMode ? 'bg-[#090d18] border-violet-950/70' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-3 shrink-0 border transition-all ${
              isDarkMode
                ? 'bg-blue-950/40 border-blue-500/50 text-blue-400 shadow-sm shadow-blue-500/20'
                : 'bg-blue-50 border-blue-200 text-blue-600'
            }`}>
              <Globe className="w-5 h-5 stroke-[1.75]" />
            </div>
            <h3 className={`text-sm font-bold mb-1.5 ${isDarkMode ? 'text-violet-300' : 'text-indigo-900'}`}>
              Real-World Applications
            </h3>
            <p className="text-xs opacity-80 leading-relaxed">
              Programming language compilers construct Abstract Syntax Trees (ASTs) to parse code, 
              and ML models use Decision Trees and Random Forests for predictive classification.
            </p>
          </div>
        </div>
      </section>

      {/* ==================================================================== */}
      {/* 4. READY TO START?                                                   */}
      {/* ==================================================================== */}
      <section
        id="section-ready-to-start"
        className={`p-6 sm:p-8 md:p-10 rounded-3xl border transition-all duration-300 ${
          isDarkMode
            ? 'bg-[#0e1424] border-violet-900/40 text-slate-100 shadow-xl shadow-violet-950/30'
            : 'bg-white border-slate-200 text-slate-900 shadow-lg shadow-slate-200/50'
        }`}
      >
        <div className="flex flex-col lg:flex-row items-center justify-between gap-6 text-center sm:text-left">
          <div className="flex flex-col sm:flex-row items-center gap-6">
            {/* Left: Static Illustrated Rocket */}
            <RocketIllustration />

            {/* Right: Heading & Short description */}
            <div className="space-y-1.5">
              <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight flex items-center justify-center sm:justify-start gap-2 flex-wrap">
                <span>Ready to Master Tree Data Structures?</span>
                <span className="text-xl sm:text-2xl select-none" aria-hidden="true">🚀</span>
              </h2>
              <p className="text-xs sm:text-sm opacity-80 max-w-xl">
                Explore tree terminology, structural classifications, traversal algorithms, 
                and interactive visualizations step-by-step.
              </p>
            </div>
          </div>

          {/* Start Learning Action Button */}
          <button
            id="overview-start-learning-btn"
            onClick={() => onNavigate('learn')}
            className={`px-6 sm:px-8 py-3 rounded-2xl text-xs sm:text-sm font-bold transition-all shadow-md flex items-center justify-center gap-2 shrink-0 cursor-pointer hover:scale-[1.02] ${
              isDarkMode
                ? 'bg-violet-600 hover:bg-violet-500 text-white shadow-violet-900/40 ring-1 ring-violet-400/50'
                : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-300/60'
            }`}
          >
            <span>Start Learning</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </section>
    </div>
  );
};
