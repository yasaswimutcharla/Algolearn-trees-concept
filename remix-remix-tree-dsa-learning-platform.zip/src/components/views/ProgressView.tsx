import React, { useState } from 'react';
import { NavItem, TopicId } from '../../types';
import { TREE_TOPICS } from '../../data/treeData';
import {
  TrendingUp,
  Award,
  CheckCircle2,
  Circle,
  ArrowRight,
  Play,
  RotateCcw,
  BookOpen,
  Layers,
  Activity,
  Terminal,
  Trophy,
  Sparkles,
  Zap,
  Check,
  Video,
  Clock,
  ExternalLink,
  Flame,
  BrainCircuit,
  GraduationCap,
  Globe
} from 'lucide-react';

interface ProgressViewProps {
  completedTopics: TopicId[];
  quizScore: { score: number; total: number } | null;
  completedGameLevels?: number[];
  completedVisualizations?: string[];
  onNavigate: (nav: NavItem, topicId?: TopicId) => void;
  onResetProgress: () => void;
  onToggleTopicCompleted?: (topicId: TopicId) => void;
  isDarkMode: boolean;
}

type ModuleFilter = 'all' | 'foundation' | 'technique' | 'analysis' | 'examination';

interface VideoLesson {
  id: TopicId;
  title: string;
  subtitle: string;
  duration: string;
  category: 'Foundation' | 'Technique' | 'Analysis';
  keyConcepts: string[];
}

const VIDEO_LESSONS: VideoLesson[] = [
  {
    id: 'basics',
    title: 'Introduction to Trees & Hierarchical Models',
    subtitle: 'Understand non-linear structures, root-leaf relationships, and the N-1 edge theorem.',
    duration: '12 mins',
    category: 'Foundation',
    keyConcepts: ['Hierarchical Nodes', 'Root & Leaves', 'N-1 Edges Formula']
  },
  {
    id: 'terminology',
    title: 'Mastering the 13 Tree Terminologies',
    subtitle: 'Deep-dive into heights, depths, node degrees, subtrees, and common interview traps.',
    duration: '16 mins',
    category: 'Foundation',
    keyConcepts: ['Depth vs Height', 'Degree of Nodes', 'Internal vs External']
  },
  {
    id: 'types',
    title: '7 Tree Classifications & Balance Factors',
    subtitle: 'Analyze Full, Complete, Perfect, Degenerate, Balanced, and AVL tree structures.',
    duration: '18 mins',
    category: 'Analysis',
    keyConcepts: ['Full vs Complete', 'Perfect Binary Tree', 'AVL Balance Factor']
  },
  {
    id: 'binary-tree',
    title: 'Binary Tree Representation & Memory Layout',
    subtitle: 'Inspect struct pointer allocations, linked representations, and array serialization formulas.',
    duration: '15 mins',
    category: 'Technique',
    keyConcepts: ['Left/Right Pointers', 'Array Indexing (2i+1)', 'Memory Overhead']
  },
  {
    id: 'traversals',
    title: 'Recursive & Iterative Tree Traversals',
    subtitle: 'Master Preorder, Inorder, Postorder, and BFS Breadth-First Level-Order execution.',
    duration: '22 mins',
    category: 'Technique',
    keyConcepts: ['Call Stack Tracking', 'BFS Queue Order', 'BST Inorder Sort']
  },
  {
    id: 'bst',
    title: 'Binary Search Trees: Search, Insert & 3 Deletion Cases',
    subtitle: 'Learn the BST ordering property, logarithmic lookups, and replacing 2-child nodes with successors.',
    duration: '24 mins',
    category: 'Technique',
    keyConcepts: ['BST Invariant', 'O(log N) Search', 'Inorder Successor']
  },
  {
    id: 'applications',
    title: 'Everyday Applications of Trees',
    subtitle: 'Explore file systems, HTML DOM trees, database indexing, and decision tree models.',
    duration: '15 mins',
    category: 'Analysis',
    keyConcepts: ['File Hierarchy', 'DOM Tree', 'Database B-Trees', 'Decision Logic']
  }
];

interface CurriculumModule {
  id: string;
  title: string;
  category: 'foundation' | 'technique' | 'analysis' | 'examination';
  categoryLabel: string;
  description: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  estTime: string;
  navTarget: NavItem;
  topicId?: TopicId;
  icon: React.FC<{ className?: string }>;
}

const CURRICULUM_MODULES: CurriculumModule[] = [
  {
    id: 'mod-basics',
    title: '1. Tree Basics & Hierarchical Paradigm',
    category: 'foundation',
    categoryLabel: 'Foundation',
    description: 'Learn why non-linear hierarchical data structures supersede linear arrays for organizational data and DOM representations.',
    difficulty: 'Beginner',
    estTime: '15 min read',
    navTarget: 'learn',
    topicId: 'basics',
    icon: Layers
  },
  {
    id: 'mod-terminology',
    title: '2. 13 Essential Tree Terminologies',
    category: 'foundation',
    categoryLabel: 'Foundation',
    description: 'Master definitions for Root, Leaf, Ancestor, Descendant, Height, Depth, and Node Degree with visual mapping.',
    difficulty: 'Beginner',
    estTime: '20 min read',
    navTarget: 'learn',
    topicId: 'terminology',
    icon: BookOpen
  },
  {
    id: 'mod-types',
    title: '3. 7 Tree Classifications & Structural Rules',
    category: 'analysis',
    categoryLabel: 'Analysis',
    description: 'Compare Full, Complete, Perfect, Balanced, Degenerate, Skewed, and Height-Balanced AVL Trees.',
    difficulty: 'Intermediate',
    estTime: '25 min read',
    navTarget: 'learn',
    topicId: 'types',
    icon: BrainCircuit
  },
  {
    id: 'mod-binary-tree',
    title: '4. Binary Tree Pointers & Memory Models',
    category: 'technique',
    categoryLabel: 'Technique',
    description: 'Examine pointer-based node references and array-based binary heap mapping formulas (2*i + 1, 2*i + 2).',
    difficulty: 'Intermediate',
    estTime: '20 min read',
    navTarget: 'learn',
    topicId: 'binary-tree',
    icon: Activity
  },
  {
    id: 'mod-traversals',
    title: '5. Tree Traversal Algorithms (DFS & BFS)',
    category: 'technique',
    categoryLabel: 'Technique',
    description: 'Step through Preorder, Inorder, Postorder recursive call stacks and Breadth-First Queue traversals.',
    difficulty: 'Intermediate',
    estTime: '30 min interactive',
    navTarget: 'visualize',
    topicId: 'traversals',
    icon: Zap
  },
  {
    id: 'mod-bst',
    title: '6. Binary Search Tree Insertion, Search & Deletion',
    category: 'technique',
    categoryLabel: 'Technique',
    description: 'Master O(log n) logarithmic lookups, BST property rules, and complex deletion with inorder successors.',
    difficulty: 'Intermediate',
    estTime: '35 min interactive',
    navTarget: 'learn',
    topicId: 'bst',
    icon: Terminal
  },
  {
    id: 'mod-applications',
    title: '7. Tree Applications & Real-World Systems',
    category: 'analysis',
    categoryLabel: 'Analysis',
    description: 'Explore file systems, HTML Document Object Models, database B-tree indexing, and machine learning decision trees.',
    difficulty: 'Beginner',
    estTime: '15 min read',
    navTarget: 'learn',
    topicId: 'applications',
    icon: Globe
  },
  {
    id: 'mod-game-quest',
    title: '8. Tree Quest Pathfinder Challenge',
    category: 'examination',
    categoryLabel: 'Examination',
    description: '5 progressive levels testing your ability to navigate BST left/right child paths against the target keys.',
    difficulty: 'Intermediate',
    estTime: '15 min game',
    navTarget: 'game',
    icon: Flame
  },
  {
    id: 'mod-quiz-exam',
    title: '9. Comprehensive 10-Question Tree DSA Exam',
    category: 'examination',
    categoryLabel: 'Examination',
    description: 'Test your conceptual and algorithmic knowledge with instant feedback, time tracking, and score breakdown.',
    difficulty: 'Advanced',
    estTime: '15 min quiz',
    navTarget: 'quiz',
    icon: Trophy
  }
];

export const ProgressView: React.FC<ProgressViewProps> = ({
  completedTopics,
  quizScore,
  completedGameLevels = [1],
  completedVisualizations = ['traversals', 'bst'],
  onNavigate,
  onResetProgress,
  isDarkMode
}) => {
  const [selectedFilter, setSelectedFilter] = useState<ModuleFilter>('all');
  const [showResetConfirm, setShowResetConfirm] = useState<boolean>(false);

  // Dynamic calculations
  const totalTopicsCount = 6;
  const topicsCompletedCount = completedTopics.length;
  const gameLevelsWonCount = Math.min(5, Math.max(1, completedGameLevels.length));
  const vizCompletedCount = Math.min(6, completedVisualizations.length);
  const quizAttempted = quizScore !== null;
  const quizPassed = quizScore !== null && quizScore.score >= 7;

  // 20 Total Activities across curriculum, visualizers, game challenges, and quizzes
  // 6 Topics + 5 Game Levels + 6 Visualizations + 3 Mastery Milestones = 20 Total Activities
  const totalActivities = 20;
  const completedActivitiesCount = Math.min(
    totalActivities,
    topicsCompletedCount +
    gameLevelsWonCount +
    vizCompletedCount +
    (quizAttempted ? (quizPassed ? 3 : 2) : 0)
  );

  const overallPercentage = Math.round((completedActivitiesCount / totalActivities) * 100);

  // Master challenges calculation (out of 4)
  let masterChallengesCount = 0;
  if (topicsCompletedCount >= 4) masterChallengesCount += 1;
  if (gameLevelsWonCount >= 4) masterChallengesCount += 1;
  if (quizScore && quizScore.score >= 8) masterChallengesCount += 1;
  if (topicsCompletedCount === 6 && quizScore && quizScore.score >= 9) masterChallengesCount += 1;

  // Recommended next step logic
  const topicSequence: { id: TopicId; title: string; reason: string }[] = [
    {
      id: 'basics',
      title: 'Tree Basics & Hierarchy',
      reason: 'Build a rock-solid foundation by understanding non-linear tree nodes, edges, and real-world hierarchical models.'
    },
    {
      id: 'terminology',
      title: '13 Tree Terminologies',
      reason: 'Learn essential terms like Root, Leaf, Height, and Depth to speak the language of algorithmic tree problems.'
    },
    {
      id: 'types',
      title: '7 Tree Classifications',
      reason: 'Discover the differences between Full, Complete, Perfect, and Balanced AVL Trees for optimal storage.'
    },
    {
      id: 'binary-tree',
      title: 'Binary Tree Memory Layout',
      reason: 'Explore pointer-based and array-based binary tree representations used inside memory allocators and heaps.'
    },
    {
      id: 'traversals',
      title: 'Tree Traversals (DFS & BFS)',
      reason: 'Master Preorder, Inorder, Postorder, and Level-Order traversals—essential for 90% of coding interview tree problems.'
    },
    {
      id: 'bst',
      title: 'Binary Search Trees (BST)',
      reason: 'Harness O(log N) searching, sorted insertions, and node deletion cases to build efficient indexing engines.'
    }
  ];

  const firstIncompleteTopic = topicSequence.find((t) => !completedTopics.includes(t.id)) || {
    id: 'bst' as TopicId,
    title: 'BST Optimization & Quiz Mastery',
    reason: 'You have reviewed all core lessons! Challenge yourself with the 10-Question Comprehensive Tree DSA Quiz to achieve 100% mastery.'
  };

  // Filter modules
  const filteredModules = CURRICULUM_MODULES.filter((mod) => {
    if (selectedFilter === 'all') return true;
    return mod.category === selectedFilter;
  });

  const isModuleCompleted = (mod: CurriculumModule): boolean => {
    if (mod.topicId && completedTopics.includes(mod.topicId)) return true;
    if (mod.category === 'examination') {
      if (mod.navTarget === 'quiz' && quizScore && quizScore.score >= 7) return true;
      if (mod.navTarget === 'game' && gameLevelsWonCount >= 4) return true;
    }
    return false;
  };

  const getFilterBadgeCount = (filter: ModuleFilter) => {
    if (filter === 'all') return CURRICULUM_MODULES.length;
    return CURRICULUM_MODULES.filter((m) => m.category === filter).length;
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 py-2">
      {/* Top Header Card */}
      <div
        className={`p-6 sm:p-8 rounded-3xl border transition-all duration-200 ${
          isDarkMode
            ? 'bg-[#0e1424] border-violet-900/40 text-slate-100 shadow-xl shadow-violet-950/30'
            : 'bg-white border-slate-200 text-slate-900 shadow-sm'
        }`}
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold font-mono tracking-wider mb-3 bg-violet-600/20 text-violet-400 border border-violet-500/30">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>LEARNING PROGRESS & MASTERY</span>
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight">
              Learning Progress & Mastery
            </h1>
            <p className="text-xs sm:text-sm mt-2 opacity-80 leading-relaxed max-w-2xl">
              Track your journey through tree concepts, algorithms, visualizations, and interactive challenges.
            </p>
          </div>

          {/* Reset Action */}
          <div className="shrink-0 flex items-center gap-3">
            {showResetConfirm ? (
              <div className="flex items-center gap-2 p-2 rounded-2xl border bg-rose-500/10 border-rose-500/30 text-rose-300">
                <span className="text-xs font-semibold px-1">Confirm reset?</span>
                <button
                  onClick={() => {
                    onResetProgress();
                    setShowResetConfirm(false);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-all shadow-md cursor-pointer"
                >
                  Yes, Reset
                </button>
                <button
                  onClick={() => setShowResetConfirm(false)}
                  className="px-2.5 py-1.5 rounded-xl bg-slate-700/60 hover:bg-slate-600 text-slate-200 text-xs font-medium transition-all cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                id="reset-progress-btn"
                onClick={() => setShowResetConfirm(true)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all cursor-pointer border ${
                  isDarkMode
                    ? 'bg-violet-950/40 hover:bg-rose-950/40 border-violet-800/40 hover:border-rose-500/50 text-slate-300 hover:text-rose-300 shadow-md'
                    : 'bg-slate-100 hover:bg-rose-50 border-slate-200 hover:border-rose-300 text-slate-700 hover:text-rose-600'
                }`}
                title="Reset learning analytics to starting state"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Progress</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Main 3-Card Progress Summary Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* CARD 1 — OVERALL COMPLETION */}
        <div
          className={`p-6 rounded-3xl border flex flex-col justify-between transition-all duration-200 ${
            isDarkMode
              ? 'bg-[#0e1424] border-violet-900/40 text-slate-100 shadow-xl shadow-violet-950/20'
              : 'bg-white border-slate-200 text-slate-900 shadow-sm'
          }`}
        >
          <div>
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold font-mono uppercase tracking-wider text-violet-400">
                OVERALL COMPLETION
              </span>
              <span className="text-xs font-semibold font-mono text-violet-400/80">
                {completedActivitiesCount} of {totalActivities} Activities
              </span>
            </div>

            <div className="mt-4 flex items-baseline gap-2">
              <span className="text-4xl sm:text-5xl font-black font-mono tracking-tight text-violet-400">
                {overallPercentage}%
              </span>
              <span className="text-xs opacity-70 font-medium">Completed</span>
            </div>

            {/* Horizontal Progress Bar */}
            <div className="w-full h-3 rounded-full bg-violet-950/50 border border-violet-800/30 overflow-hidden mt-5 p-0.5">
              <div
                className="h-full rounded-full bg-gradient-to-r from-violet-600 via-indigo-500 to-cyan-400 transition-all duration-700 shadow-sm shadow-violet-500/50"
                style={{ width: `${Math.max(5, overallPercentage)}%` }}
              />
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-violet-950/50 flex items-center justify-between text-[11px] font-mono opacity-70">
            <span className="flex items-center gap-1 font-semibold">
              <span className="w-1.5 h-1.5 rounded-full bg-violet-400" />
              0% Beginner
            </span>
            <span className="flex items-center gap-1 font-semibold">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
              100% Master
            </span>
          </div>
        </div>

        {/* CARD 2 — PERFORMANCE STATS */}
        <div
          className={`p-6 rounded-3xl border flex flex-col justify-between transition-all duration-200 ${
            isDarkMode
              ? 'bg-[#0e1424] border-violet-900/40 text-slate-100 shadow-xl shadow-violet-950/20'
              : 'bg-white border-slate-200 text-slate-900 shadow-sm'
          }`}
        >
          <div>
            <div className="text-[11px] font-bold font-mono uppercase tracking-wider text-violet-400 mb-4">
              PERFORMANCE STATS
            </div>

            <div className="grid grid-cols-3 gap-2 text-center py-2">
              {/* Stat 1: Topics Mastered */}
              <div className={`p-3 rounded-2xl border ${isDarkMode ? 'bg-[#090d18] border-violet-950/70' : 'bg-slate-50 border-slate-200'}`}>
                <div className="text-xl sm:text-2xl font-black font-mono text-violet-400">
                  {String(topicsCompletedCount).padStart(2, '0')}
                </div>
                <div className="text-[10px] font-bold font-mono tracking-wider uppercase opacity-70 mt-1">
                  MASTERED
                </div>
              </div>

              {/* Stat 2: Activities Completed */}
              <div className={`p-3 rounded-2xl border ${isDarkMode ? 'bg-[#090d18] border-violet-950/70' : 'bg-slate-50 border-slate-200'}`}>
                <div className="text-xl sm:text-2xl font-black font-mono text-cyan-400">
                  {String(completedActivitiesCount).padStart(2, '0')} / 20
                </div>
                <div className="text-[10px] font-bold font-mono tracking-wider uppercase opacity-70 mt-1">
                  ACTIVITIES
                </div>
              </div>

              {/* Stat 3: Levels Won */}
              <div className={`p-3 rounded-2xl border ${isDarkMode ? 'bg-[#090d18] border-violet-950/70' : 'bg-slate-50 border-slate-200'}`}>
                <div className="text-xl sm:text-2xl font-black font-mono text-pink-400">
                  {String(gameLevelsWonCount).padStart(2, '0')} / 05
                </div>
                <div className="text-[10px] font-bold font-mono tracking-wider uppercase opacity-70 mt-1">
                  LEVELS WON
                </div>
              </div>
            </div>
          </div>

          {/* Master Challenges Highlight */}
          <div className="mt-4 pt-3 border-t border-violet-950/50">
            <div className={`p-3 rounded-2xl border flex items-center justify-between text-xs font-semibold ${
              isDarkMode ? 'bg-violet-950/40 border-violet-800/40 text-violet-200' : 'bg-indigo-50 border-indigo-200 text-indigo-900'
            }`}>
              <div className="flex items-center gap-2">
                <span className="text-base">🏆</span>
                <span>Master Challenges:</span>
              </div>
              <span className="font-mono font-bold text-violet-400">
                {masterChallengesCount} / 4 Challenges
              </span>
            </div>
          </div>
        </div>

        {/* CARD 3 — RECOMMENDED NEXT STEP */}
        <div
          className={`p-6 rounded-3xl border flex flex-col justify-between transition-all duration-200 relative overflow-hidden ${
            isDarkMode
              ? 'bg-[#0e1424] border-violet-900/40 text-slate-100 shadow-xl shadow-violet-950/20'
              : 'bg-white border-slate-200 text-slate-900 shadow-sm'
          }`}
        >
          <div>
            <div className="flex items-center gap-2 text-[11px] font-bold font-mono uppercase tracking-wider text-cyan-400 mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>RECOMMENDED NEXT STEP</span>
            </div>

            <h3 className="text-lg font-extrabold tracking-tight mt-1 text-violet-300">
              {firstIncompleteTopic.title}
            </h3>

            <p className="text-xs opacity-80 leading-relaxed mt-2.5 line-clamp-3">
              {firstIncompleteTopic.reason}
            </p>
          </div>

          <div className="mt-5">
            <button
              onClick={() => onNavigate('learn', firstIncompleteTopic.id)}
              className={`w-full flex items-center justify-center gap-2 px-5 py-3 rounded-2xl font-bold text-xs uppercase tracking-wider transition-all cursor-pointer shadow-lg ${
                isDarkMode
                  ? 'bg-violet-600 hover:bg-violet-500 text-white shadow-violet-900/50 ring-1 ring-violet-400/40 hover:scale-[1.02]'
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-300 hover:scale-[1.02]'
              }`}
            >
              <span>CONTINUE LEARNING →</span>
            </button>
          </div>
        </div>
      </div>

      {/* VIDEO LESSONS / LEARNING MATERIAL SECTION */}
      <div
        className={`p-6 sm:p-8 rounded-3xl border transition-all duration-200 ${
          isDarkMode
            ? 'bg-[#0e1424] border-violet-900/40 text-slate-100 shadow-xl shadow-violet-950/20'
            : 'bg-white border-slate-200 text-slate-900 shadow-sm'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 ${
              isDarkMode ? 'bg-violet-600/20 text-violet-400 border border-violet-500/30' : 'bg-indigo-100 text-indigo-600'
            }`}>
              <Video className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight">
                VIDEO LESSONS
              </h2>
              <p className="text-xs opacity-75 mt-0.5">
                Structured multimedia walkthroughs and interactive concept deep-dives.
              </p>
            </div>
          </div>

          {/* Lesson Counter Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-mono font-bold bg-violet-600/20 text-violet-300 border border-violet-500/30">
            <span>{topicsCompletedCount} of {VIDEO_LESSONS.length} Completed</span>
          </div>
        </div>

        {/* Video Lesson Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {VIDEO_LESSONS.map((lesson, idx) => {
            const isCompleted = completedTopics.includes(lesson.id);

            return (
              <div
                key={lesson.id}
                onClick={() => onNavigate('learn', lesson.id)}
                className={`p-5 rounded-2xl border transition-all duration-200 cursor-pointer flex flex-col justify-between group ${
                  isDarkMode
                    ? isCompleted
                      ? 'bg-[#090d18] border-violet-800/40 hover:border-violet-500/60 shadow-md'
                      : 'bg-[#090d18] border-violet-950/70 hover:border-violet-700/50'
                    : isCompleted
                    ? 'bg-slate-50 border-indigo-200 hover:border-indigo-400'
                    : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-full uppercase tracking-wider bg-violet-950/60 text-violet-300 border border-violet-800/30">
                      Lesson 0{idx + 1} • {lesson.category}
                    </span>

                    {isCompleted ? (
                      <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-950/40 border border-emerald-700/40 px-2 py-0.5 rounded-full">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Completed</span>
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-[11px] font-medium text-slate-400 bg-slate-800/40 border border-slate-700/40 px-2 py-0.5 rounded-full">
                        <Circle className="w-3 h-3" />
                        <span>Not completed</span>
                      </span>
                    )}
                  </div>

                  <h4 className="text-sm font-bold tracking-tight group-hover:text-violet-300 transition-colors">
                    {lesson.title}
                  </h4>
                  <p className="text-xs opacity-75 mt-1.5 leading-relaxed line-clamp-2">
                    {lesson.subtitle}
                  </p>

                  {/* Key Concepts Tags */}
                  <div className="flex flex-wrap gap-1.5 mt-3">
                    {lesson.keyConcepts.map((concept, cIdx) => (
                      <span
                        key={cIdx}
                        className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-violet-950/40 text-slate-300 border border-violet-900/30"
                      >
                        {concept}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-violet-950/40 flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1 opacity-70 font-mono text-[11px]">
                    <Clock className="w-3 h-3" />
                    {lesson.duration}
                  </span>

                  <span className="font-bold text-violet-400 group-hover:text-violet-300 flex items-center gap-1">
                    <span>{isCompleted ? 'Review' : 'Start Lesson'}</span>
                    <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* CURRICULUM MODULES WITH CATEGORY FILTERS */}
      <div
        className={`p-6 sm:p-8 rounded-3xl border transition-all duration-200 ${
          isDarkMode
            ? 'bg-[#0e1424] border-violet-900/40 text-slate-100 shadow-xl shadow-violet-950/20'
            : 'bg-white border-slate-200 text-slate-900 shadow-sm'
        }`}
      >
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight flex items-center gap-2.5">
              <GraduationCap className="w-6 h-6 text-violet-400" />
              <span>Tree DSA Curriculum Modules</span>
            </h2>
            <p className="text-xs opacity-75 mt-1">
              Filter by syllabus category to review specific theoretical and hands-on modules.
            </p>
          </div>

          {/* Module Counter */}
          <div className="text-xs font-mono font-semibold opacity-70">
            Showing {filteredModules.length} of {CURRICULUM_MODULES.length} modules
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap gap-2 mb-6">
          {(
            [
              { id: 'all', label: 'All Modules' },
              { id: 'foundation', label: 'Foundation' },
              { id: 'technique', label: 'Technique' },
              { id: 'analysis', label: 'Analysis' },
              { id: 'examination', label: 'Examination' }
            ] as { id: ModuleFilter; label: string }[]
          ).map((filter) => {
            const isSelected = selectedFilter === filter.id;
            const count = getFilterBadgeCount(filter.id);

            return (
              <button
                key={filter.id}
                onClick={() => setSelectedFilter(filter.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                  isSelected
                    ? isDarkMode
                      ? 'bg-violet-600 text-white shadow-lg shadow-violet-900/40 ring-1 ring-violet-400/40'
                      : 'bg-indigo-600 text-white shadow-md shadow-indigo-300'
                    : isDarkMode
                    ? 'bg-[#090d18] hover:bg-violet-950/40 text-slate-300 border border-violet-950/80 hover:border-violet-700/40'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
                }`}
              >
                <span>{filter.label}</span>
                <span
                  className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded-full ${
                    isSelected
                      ? 'bg-white/20 text-white'
                      : isDarkMode
                      ? 'bg-violet-950/80 text-violet-300'
                      : 'bg-slate-200 text-slate-700'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Modules List Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredModules.map((module) => {
            const Icon = module.icon;
            const completed = isModuleCompleted(module);

            return (
              <div
                key={module.id}
                onClick={() => onNavigate(module.navTarget, module.topicId)}
                className={`p-5 rounded-2xl border transition-all duration-200 cursor-pointer flex flex-col justify-between group ${
                  isDarkMode
                    ? 'bg-[#090d18] border-violet-950/70 hover:border-violet-600/50 hover:shadow-lg hover:shadow-violet-950/40'
                    : 'bg-slate-50 border-slate-200 hover:border-indigo-300 hover:shadow-md'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 border transition-all ${
                        isDarkMode
                          ? 'bg-violet-950/40 border-violet-500/50 text-violet-400 shadow-sm shadow-violet-500/20 group-hover:border-violet-400'
                          : 'bg-violet-50 border-violet-200 text-violet-600 group-hover:border-violet-300'
                      }`}>
                        <Icon className="w-4 h-4 stroke-[1.75]" />
                      </div>
                      <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-violet-400">
                        {module.categoryLabel}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${
                          module.difficulty === 'Beginner'
                            ? 'bg-emerald-950/30 text-emerald-300 border-emerald-800/30'
                            : module.difficulty === 'Intermediate'
                            ? 'bg-amber-950/30 text-amber-300 border-amber-800/30'
                            : 'bg-pink-950/30 text-pink-300 border-pink-800/30'
                        }`}
                      >
                        {module.difficulty}
                      </span>

                      {completed ? (
                        <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-400">
                          <CheckCircle2 className="w-4 h-4" />
                        </span>
                      ) : (
                        <Circle className="w-4 h-4 opacity-30" />
                      )}
                    </div>
                  </div>

                  <h4 className="text-sm font-bold tracking-tight group-hover:text-violet-300 transition-colors">
                    {module.title}
                  </h4>
                  <p className="text-xs opacity-75 mt-1.5 leading-relaxed">
                    {module.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-violet-950/40 flex items-center justify-between text-xs">
                  <span className="text-[11px] font-mono opacity-60">
                    {module.estTime}
                  </span>

                  <span className="font-bold text-violet-400 group-hover:text-violet-300 flex items-center gap-1">
                    <span>{completed ? 'Review Module' : 'Launch Module'}</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
