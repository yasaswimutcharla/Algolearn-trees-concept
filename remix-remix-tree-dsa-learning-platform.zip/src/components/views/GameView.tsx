import React, { useState, useEffect } from 'react';
import {
  Gamepad2,
  Trophy,
  RotateCcw,
  Sparkles,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Zap,
  Flame,
  ArrowRight,
  RefreshCw
} from 'lucide-react';

interface GameViewProps {
  isDarkMode: boolean;
}

interface GameLevel {
  id: number;
  title: string;
  instruction: string;
  initialTree: number[];
  targetValue: number;
  correctPath: ('left' | 'right')[];
  hint: string;
  explanation: string;
}

const LEVELS: GameLevel[] = [
  {
    id: 1,
    title: 'Level 1: Find the Target Node',
    instruction: 'Locate node 25 in the Binary Search Tree. Decide whether to go LEFT or RIGHT from the root.',
    initialTree: [50, 25, 75, 12, 37, 62, 87],
    targetValue: 25,
    correctPath: ['left'],
    hint: 'Since 25 < 50, compare and move to the left child.',
    explanation: 'In a BST, all values smaller than the current node lie in the left subtree.'
  },
  {
    id: 2,
    title: 'Level 2: Multi-Step Navigation',
    instruction: 'Find node 87 in the tree by following BST search rules step-by-step.',
    initialTree: [50, 25, 75, 12, 37, 62, 87],
    targetValue: 87,
    correctPath: ['right', 'right'],
    hint: '87 > 50 (go RIGHT to 75), then 87 > 75 (go RIGHT to 87).',
    explanation: 'Each step cuts the remaining search space in half, resulting in O(log N) efficiency.'
  },
  {
    id: 3,
    title: 'Level 3: Deep Traversal',
    instruction: 'Find node 37 in the BST. Navigate carefully through each branch.',
    initialTree: [50, 25, 75, 12, 37, 62, 87],
    targetValue: 37,
    correctPath: ['left', 'right'],
    hint: '37 < 50 (LEFT to 25), then 37 > 25 (RIGHT to 37).',
    explanation: 'Moving Left then Right targets keys located between 25 and 50.'
  },
  {
    id: 4,
    title: 'Level 4: Spot the Leaf',
    instruction: 'Navigate to node 62 from root 50.',
    initialTree: [50, 25, 75, 12, 37, 62, 87],
    targetValue: 62,
    correctPath: ['right', 'left'],
    hint: '62 > 50 (RIGHT to 75), then 62 < 75 (LEFT to 62).',
    explanation: '62 is in the right subtree of 50 and left subtree of 75.'
  },
  {
    id: 5,
    title: 'Level 5: Master Challenge',
    instruction: 'Find node 12 in the BST without making any mistakes!',
    initialTree: [50, 25, 75, 12, 37, 62, 87],
    targetValue: 12,
    correctPath: ['left', 'left'],
    hint: '12 < 50 (LEFT to 25), then 12 < 25 (LEFT to 12).',
    explanation: '12 is the smallest element in this BST, found at the leftmost node.'
  }
];

export const GameView: React.FC<GameViewProps> = ({ isDarkMode }) => {
  const [currentLevelIdx, setCurrentLevelIdx] = useState<number>(0);
  const [userPath, setUserPath] = useState<('left' | 'right')[]>([]);
  const [currentNodeVal, setCurrentNodeVal] = useState<number>(50);
  const [score, setScore] = useState<number>(0);
  const [streak, setStreak] = useState<number>(0);
  const [feedback, setFeedback] = useState<{ status: 'correct' | 'wrong' | 'in_progress'; message: string }>({
    status: 'in_progress',
    message: 'Make your move: Click Left or Right to search for the target.'
  });
  const [showHint, setShowHint] = useState<boolean>(false);

  const level = LEVELS[currentLevelIdx];

  // Reset node when level changes
  useEffect(() => {
    setCurrentNodeVal(50);
    setUserPath([]);
    setShowHint(false);
    setFeedback({
      status: 'in_progress',
      message: `Target: Find node ${level.targetValue}. Compare it with current node 50.`
    });
  }, [currentLevelIdx, level.targetValue]);

  const handleDecision = (direction: 'left' | 'right') => {
    if (feedback.status === 'correct') return;

    const newPath = [...userPath, direction];
    setUserPath(newPath);

    // Compute next node value based on tree structure
    let nextVal = currentNodeVal;
    if (currentNodeVal === 50) {
      nextVal = direction === 'left' ? 25 : 75;
    } else if (currentNodeVal === 25) {
      nextVal = direction === 'left' ? 12 : 37;
    } else if (currentNodeVal === 75) {
      nextVal = direction === 'left' ? 62 : 87;
    }

    setCurrentNodeVal(nextVal);

    // Check if correct so far
    const stepIndex = newPath.length - 1;
    const isStepCorrect = level.correctPath[stepIndex] === direction;

    if (!isStepCorrect) {
      setStreak(0);
      setFeedback({
        status: 'wrong',
        message: `Incorrect step! ${level.targetValue} ${
          direction === 'left' ? 'is greater than' : 'is less than'
        } ${currentNodeVal}. Try resetting the level.`
      });
    } else if (newPath.length === level.correctPath.length && nextVal === level.targetValue) {
      // Level completed
      setScore((prev) => prev + 100 + streak * 20);
      setStreak((prev) => prev + 1);
      setFeedback({
        status: 'correct',
        message: `Target Found! ${level.explanation}`
      });
    } else {
      setFeedback({
        status: 'in_progress',
        message: `Good step! Now compare target ${level.targetValue} with current node ${nextVal}.`
      });
    }
  };

  const handleResetLevel = () => {
    setCurrentNodeVal(50);
    setUserPath([]);
    setShowHint(false);
    setFeedback({
      status: 'in_progress',
      message: `Target: Find node ${level.targetValue}. Compare it with current node 50.`
    });
  };

  const handleNextLevel = () => {
    if (currentLevelIdx < LEVELS.length - 1) {
      setCurrentLevelIdx((prev) => prev + 1);
    } else {
      // Completed all levels
      setCurrentLevelIdx(0);
      setFeedback({
        status: 'in_progress',
        message: 'Congratulations! You mastered all tree quest levels!'
      });
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 py-2">
      {/* Header Banner */}
      <div
        className={`p-6 sm:p-8 rounded-3xl border transition-all ${
          isDarkMode
            ? 'bg-[#0e1424] border-violet-900/40 text-slate-100 shadow-xl shadow-violet-950/30'
            : 'bg-white border-slate-200 text-slate-900 shadow-lg shadow-slate-200/50'
        }`}
      >
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider border bg-violet-500/10 text-violet-400 border-violet-500/30">
              <Gamepad2 className="w-3.5 h-3.5" />
              <span>Tree Navigator Game</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              BST Pathfinding Quest
            </h1>
            <p className="text-xs sm:text-sm opacity-80 max-w-xl">
              Guide the search pointer through the tree branches by following BST ordering properties.
            </p>
          </div>

          {/* Stats Badges */}
          <div className="flex items-center gap-3 self-stretch sm:self-auto">
            <div
              className={`flex-1 sm:flex-none px-4 py-2.5 rounded-2xl border text-center ${
                isDarkMode ? 'bg-[#090d18] border-violet-950/80' : 'bg-slate-50 border-slate-200'
              }`}
            >
              <div className="text-[10px] font-bold uppercase opacity-60">Score</div>
              <div className="text-lg font-black text-violet-400">{score}</div>
            </div>
            <div
              className={`flex-1 sm:flex-none px-4 py-2.5 rounded-2xl border text-center ${
                isDarkMode ? 'bg-[#090d18] border-violet-950/80' : 'bg-slate-50 border-slate-200'
              }`}
            >
              <div className="text-[10px] font-bold uppercase opacity-60">Streak</div>
              <div className="text-lg font-black text-amber-400 flex items-center justify-center gap-1">
                <Flame className="w-4 h-4" />
                <span>{streak}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Game Stage Area */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Left / Main Stage: Visual Tree & Target */}
        <div
          className={`md:col-span-8 p-6 rounded-3xl border flex flex-col items-center justify-between min-h-[380px] ${
            isDarkMode ? 'bg-[#0e1424] border-violet-900/40' : 'bg-white border-slate-200'
          }`}
        >
          <div className="w-full flex items-center justify-between border-b pb-3 mb-2 border-inherit">
            <span className="text-xs font-bold text-violet-400">
              Level {level.id} of {LEVELS.length}
            </span>
            <div className="flex items-center gap-2">
              <span className="text-xs opacity-70">Target Value:</span>
              <span className="px-2.5 py-0.5 rounded-full font-mono font-bold text-xs bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                {level.targetValue}
              </span>
            </div>
          </div>

          {/* Interactive Visual Tree */}
          <div className="w-full py-4 flex justify-center">
            <svg viewBox="0 0 320 180" className="w-full max-w-sm select-none">
              <defs>
                <linearGradient id="gameEdge" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor={isDarkMode ? '#8b5cf6' : '#6366f1'} />
                  <stop offset="100%" stopColor={isDarkMode ? '#6d28d9' : '#4f46e5'} />
                </linearGradient>
              </defs>

              {/* Edges */}
              <line x1="160" y1="30" x2="80" y2="80" stroke="url(#gameEdge)" strokeWidth="2.5" strokeOpacity="0.4" />
              <line x1="160" y1="30" x2="240" y2="80" stroke="url(#gameEdge)" strokeWidth="2.5" strokeOpacity="0.4" />
              <line x1="80" y1="80" x2="40" y2="135" stroke="url(#gameEdge)" strokeWidth="2" strokeOpacity="0.3" />
              <line x1="80" y1="80" x2="120" y2="135" stroke="url(#gameEdge)" strokeWidth="2" strokeOpacity="0.3" />
              <line x1="240" y1="80" x2="200" y2="135" stroke="url(#gameEdge)" strokeWidth="2" strokeOpacity="0.3" />
              <line x1="240" y1="80" x2="280" y2="135" stroke="url(#gameEdge)" strokeWidth="2" strokeOpacity="0.3" />

              {/* Node 50 (Root) */}
              <g transform="translate(160, 30)">
                <circle
                  r="18"
                  fill={currentNodeVal === 50 ? '#8b5cf6' : isDarkMode ? '#172036' : '#f1f5f9'}
                  stroke={currentNodeVal === 50 ? '#c4b5fd' : isDarkMode ? '#475569' : '#cbd5e1'}
                  strokeWidth="2.5"
                />
                <text y="5" textAnchor="middle" fill={currentNodeVal === 50 ? '#ffffff' : isDarkMode ? '#e2e8f0' : '#1e293b'} fontSize="12" fontWeight="bold">
                  50
                </text>
              </g>

              {/* Node 25 */}
              <g transform="translate(80, 80)">
                <circle
                  r="16"
                  fill={currentNodeVal === 25 ? '#8b5cf6' : level.targetValue === 25 && feedback.status === 'correct' ? '#10b981' : isDarkMode ? '#172036' : '#f1f5f9'}
                  stroke={currentNodeVal === 25 ? '#c4b5fd' : isDarkMode ? '#475569' : '#cbd5e1'}
                  strokeWidth="2"
                />
                <text y="4" textAnchor="middle" fill={currentNodeVal === 25 || (level.targetValue === 25 && feedback.status === 'correct') ? '#ffffff' : isDarkMode ? '#e2e8f0' : '#1e293b'} fontSize="11" fontWeight="bold">
                  25
                </text>
              </g>

              {/* Node 75 */}
              <g transform="translate(240, 80)">
                <circle
                  r="16"
                  fill={currentNodeVal === 75 ? '#8b5cf6' : level.targetValue === 75 && feedback.status === 'correct' ? '#10b981' : isDarkMode ? '#172036' : '#f1f5f9'}
                  stroke={currentNodeVal === 75 ? '#c4b5fd' : isDarkMode ? '#475569' : '#cbd5e1'}
                  strokeWidth="2"
                />
                <text y="4" textAnchor="middle" fill={currentNodeVal === 75 || (level.targetValue === 75 && feedback.status === 'correct') ? '#ffffff' : isDarkMode ? '#e2e8f0' : '#1e293b'} fontSize="11" fontWeight="bold">
                  75
                </text>
              </g>

              {/* Leaf Nodes */}
              {[
                { val: 12, x: 40, y: 135 },
                { val: 37, x: 120, y: 135 },
                { val: 62, x: 200, y: 135 },
                { val: 87, x: 280, y: 135 }
              ].map((n) => (
                <g key={n.val} transform={`translate(${n.x}, ${n.y})`}>
                  <circle
                    r="14"
                    fill={currentNodeVal === n.val ? '#8b5cf6' : level.targetValue === n.val && feedback.status === 'correct' ? '#10b981' : isDarkMode ? '#172036' : '#f1f5f9'}
                    stroke={currentNodeVal === n.val ? '#c4b5fd' : isDarkMode ? '#475569' : '#cbd5e1'}
                    strokeWidth="1.5"
                  />
                  <text y="4" textAnchor="middle" fill={currentNodeVal === n.val || (level.targetValue === n.val && feedback.status === 'correct') ? '#ffffff' : isDarkMode ? '#e2e8f0' : '#1e293b'} fontSize="10" fontWeight="bold">
                    {n.val}
                  </text>
                </g>
              ))}
            </svg>
          </div>

          {/* Feedback banner */}
          <div
            className={`w-full p-3 rounded-2xl flex items-center gap-3 text-xs transition-all ${
              feedback.status === 'correct'
                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                : feedback.status === 'wrong'
                ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                : isDarkMode
                ? 'bg-[#090d18] text-slate-300 border border-violet-950/80'
                : 'bg-slate-50 text-slate-700 border border-slate-200'
            }`}
          >
            {feedback.status === 'correct' ? (
              <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-400" />
            ) : feedback.status === 'wrong' ? (
              <XCircle className="w-5 h-5 shrink-0 text-rose-400" />
            ) : (
              <Sparkles className="w-5 h-5 shrink-0 text-violet-400" />
            )}
            <span className="flex-1 font-medium">{feedback.message}</span>
          </div>
        </div>

        {/* Right Stage: Controls & Decision Making */}
        <div className="md:col-span-4 space-y-4 flex flex-col justify-between">
          <div
            className={`p-6 rounded-3xl border space-y-4 ${
              isDarkMode ? 'bg-[#0e1424] border-violet-900/40' : 'bg-white border-slate-200'
            }`}
          >
            <h3 className="font-bold text-sm">Navigation Controls</h3>
            <p className="text-xs opacity-70">
              Current Node: <span className="font-mono font-bold text-violet-400">{currentNodeVal}</span>
            </p>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                id="btn-go-left"
                disabled={feedback.status === 'correct' || feedback.status === 'wrong'}
                onClick={() => handleDecision('left')}
                className={`py-3.5 px-4 rounded-xl font-bold text-xs flex flex-col items-center gap-1 transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${
                  isDarkMode
                    ? 'bg-[#151d30] hover:bg-violet-900/40 text-violet-300 border border-violet-800/40'
                    : 'bg-slate-100 hover:bg-indigo-50 text-indigo-700 border border-slate-200'
                }`}
              >
                <span>← GO LEFT</span>
                <span className="text-[10px] opacity-60 font-normal">Target &lt; {currentNodeVal}</span>
              </button>

              <button
                id="btn-go-right"
                disabled={feedback.status === 'correct' || feedback.status === 'wrong'}
                onClick={() => handleDecision('right')}
                className={`py-3.5 px-4 rounded-xl font-bold text-xs flex flex-col items-center gap-1 transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${
                  isDarkMode
                    ? 'bg-[#151d30] hover:bg-violet-900/40 text-violet-300 border border-violet-800/40'
                    : 'bg-slate-100 hover:bg-indigo-50 text-indigo-700 border border-slate-200'
                }`}
              >
                <span>GO RIGHT →</span>
                <span className="text-[10px] opacity-60 font-normal">Target &gt; {currentNodeVal}</span>
              </button>
            </div>

            {/* Hint & Reset */}
            <div className="pt-2 flex items-center justify-between gap-2 border-t border-inherit">
              <button
                onClick={() => setShowHint(!showHint)}
                className="text-xs font-semibold text-violet-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>{showHint ? 'Hide Hint' : 'Need a Hint?'}</span>
              </button>

              <button
                onClick={handleResetLevel}
                className="p-2 rounded-xl opacity-60 hover:opacity-100 transition-opacity cursor-pointer"
                title="Reset Current Level"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>

            {showHint && (
              <div className="p-3 rounded-xl bg-violet-500/10 border border-violet-500/20 text-xs text-violet-300">
                💡 {level.hint}
              </div>
            )}
          </div>

          {/* Next Level Action Button */}
          {feedback.status === 'correct' && (
            <button
              id="btn-next-game-level"
              onClick={handleNextLevel}
              className={`w-full py-4 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-lg cursor-pointer ${
                isDarkMode
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-950/50'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-200'
              }`}
            >
              <span>{currentLevelIdx < LEVELS.length - 1 ? 'Next Level' : 'Play Again'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
