import React from 'react';
import { Network, Lightbulb, CheckCircle2, GitBranch, ArrowRight } from 'lucide-react';

interface BinaryTreeTypesSectionProps {
  isDarkMode: boolean;
}

interface TreeTypeSpec {
  id: string;
  number: number;
  name: string;
  badge: string;
  definition: string;
  explanation: string;
  example: string;
  keyPoint: string;
  renderDiagram: (isDarkMode: boolean) => React.ReactNode;
}

export const BinaryTreeTypesSection: React.FC<BinaryTreeTypesSectionProps> = ({ isDarkMode }) => {
  const types: TreeTypeSpec[] = [
    {
      id: 'strictly',
      number: 1,
      name: 'Strictly Binary Tree',
      badge: '0 or 2 Children Rule',
      definition: 'A binary tree where every node has either zero (0) children or exactly two (2) children.',
      explanation: 'In a strictly binary tree, no node is ever allowed to have only 1 child. Every single node is either a parent with both left and right children, or a leaf node with no children at all.',
      example: 'Root node 10 has two children: 5 and 15. Nodes 5 and 15 have 0 children (leaves).',
      keyPoint: 'How to recognize: Check every node in the tree. If you see any node with only 1 child, it is NOT strictly binary. Every node must have 0 or 2 children.',
      renderDiagram: (dark) => (
        <svg viewBox="0 0 360 170" className="w-full max-w-sm h-auto">
          {/* Connecting Edges */}
          <line
            x1="180"
            y1="40"
            x2="100"
            y2="110"
            stroke={dark ? '#8b5cf6' : '#6366f1'}
            strokeWidth="2.5"
          />
          <line
            x1="180"
            y1="40"
            x2="260"
            y2="110"
            stroke={dark ? '#8b5cf6' : '#6366f1'}
            strokeWidth="2.5"
          />

          {/* Root Node 10 */}
          <g>
            <circle
              cx="180"
              cy="40"
              r="22"
              fill={dark ? '#7c3aed' : '#4f46e5'}
              stroke={dark ? '#c4b5fd' : '#818cf8'}
              strokeWidth="2"
            />
            <text x="180" y="45" fill="#ffffff" fontSize="13" fontWeight="bold" textAnchor="middle">
              10
            </text>
            <rect
              x="212"
              y="28"
              width="88"
              height="22"
              rx="6"
              fill={dark ? '#3b0764' : '#f5f3ff'}
              stroke={dark ? '#a855f7' : '#c084fc'}
              strokeWidth="1"
            />
            <text
              x="256"
              y="43"
              fill={dark ? '#e9d5ff' : '#6b21a8'}
              fontSize="10"
              fontWeight="bold"
              textAnchor="middle"
            >
              2 Children (Root)
            </text>
          </g>

          {/* Left Leaf Node 5 */}
          <g>
            <circle
              cx="100"
              cy="110"
              r="20"
              fill={dark ? '#064e3b' : '#d1fae5'}
              stroke={dark ? '#34d399' : '#059669'}
              strokeWidth="2"
            />
            <text
              x="100"
              y="115"
              fill={dark ? '#a7f3d0' : '#065f46'}
              fontSize="12"
              fontWeight="bold"
              textAnchor="middle"
            >
              5
            </text>
            <text
              x="100"
              y="145"
              fill={dark ? '#6ee7b7' : '#047857'}
              fontSize="10"
              fontWeight="600"
              textAnchor="middle"
            >
              0 Children (Leaf)
            </text>
          </g>

          {/* Right Leaf Node 15 */}
          <g>
            <circle
              cx="260"
              cy="110"
              r="20"
              fill={dark ? '#064e3b' : '#d1fae5'}
              stroke={dark ? '#34d399' : '#059669'}
              strokeWidth="2"
            />
            <text
              x="260"
              y="115"
              fill={dark ? '#a7f3d0' : '#065f46'}
              fontSize="12"
              fontWeight="bold"
              textAnchor="middle"
            >
              15
            </text>
            <text
              x="260"
              y="145"
              fill={dark ? '#6ee7b7' : '#047857'}
              fontSize="10"
              fontWeight="600"
              textAnchor="middle"
            >
              0 Children (Leaf)
            </text>
          </g>
        </svg>
      )
    },
    {
      id: 'full',
      number: 2,
      name: 'Full Binary Tree',
      badge: 'Strict 0 or 2 Children',
      definition: 'A binary tree in which every single node has either zero (0) or exactly two (2) children.',
      explanation: 'Every non-leaf (parent) node splits cleanly into both a left and right child. There are no dangling single children anywhere in the tree structure.',
      example: 'Root 10 connects to 5 and 15. Node 5 connects to 2 and 7. Node 15 connects to 12 and 18. Nodes 2, 7, 12, and 18 are all leaf nodes.',
      keyPoint: 'How to recognize: Scan all nodes in the tree — every node has either 2 children or 0 children. No node has just 1 child.',
      renderDiagram: (dark) => (
        <svg viewBox="0 0 380 190" className="w-full max-w-md h-auto">
          {/* Edges from 10 */}
          <line x1="190" y1="35" x2="105" y2="90" stroke={dark ? '#8b5cf6' : '#6366f1'} strokeWidth="2" />
          <line x1="190" y1="35" x2="275" y2="90" stroke={dark ? '#8b5cf6' : '#6366f1'} strokeWidth="2" />
          {/* Edges from 5 */}
          <line x1="105" y1="90" x2="65" y2="145" stroke={dark ? '#8b5cf6' : '#6366f1'} strokeWidth="2" />
          <line x1="105" y1="90" x2="145" y2="145" stroke={dark ? '#8b5cf6' : '#6366f1'} strokeWidth="2" />
          {/* Edges from 15 */}
          <line x1="275" y1="90" x2="235" y2="145" stroke={dark ? '#8b5cf6' : '#6366f1'} strokeWidth="2" />
          <line x1="275" y1="90" x2="315" y2="145" stroke={dark ? '#8b5cf6' : '#6366f1'} strokeWidth="2" />

          {/* Root 10 */}
          <circle cx="190" cy="35" r="18" fill={dark ? '#7c3aed' : '#4f46e5'} stroke="#ffffff" strokeWidth="2" />
          <text x="190" y="39" fill="#ffffff" fontSize="12" fontWeight="bold" textAnchor="middle">10</text>

          {/* Node 5 */}
          <circle cx="105" cy="90" r="17" fill={dark ? '#2e1065' : '#e0e7ff'} stroke={dark ? '#a78bfa' : '#6366f1'} strokeWidth="2" />
          <text x="105" y="94" fill={dark ? '#e9d5ff' : '#312e81'} fontSize="11" fontWeight="bold" textAnchor="middle">5</text>

          {/* Node 15 */}
          <circle cx="275" cy="90" r="17" fill={dark ? '#2e1065' : '#e0e7ff'} stroke={dark ? '#a78bfa' : '#6366f1'} strokeWidth="2" />
          <text x="275" y="94" fill={dark ? '#e9d5ff' : '#312e81'} fontSize="11" fontWeight="bold" textAnchor="middle">15</text>

          {/* Leaves: 2, 7, 12, 18 */}
          <circle cx="65" cy="145" r="15" fill={dark ? '#064e3b' : '#d1fae5'} stroke={dark ? '#34d399' : '#059669'} strokeWidth="1.5" />
          <text x="65" y="149" fill={dark ? '#a7f3d0' : '#065f46'} fontSize="10" fontWeight="bold" textAnchor="middle">2</text>

          <circle cx="145" cy="145" r="15" fill={dark ? '#064e3b' : '#d1fae5'} stroke={dark ? '#34d399' : '#059669'} strokeWidth="1.5" />
          <text x="145" y="149" fill={dark ? '#a7f3d0' : '#065f46'} fontSize="10" fontWeight="bold" textAnchor="middle">7</text>

          <circle cx="235" cy="145" r="15" fill={dark ? '#064e3b' : '#d1fae5'} stroke={dark ? '#34d399' : '#059669'} strokeWidth="1.5" />
          <text x="235" y="149" fill={dark ? '#a7f3d0' : '#065f46'} fontSize="10" fontWeight="bold" textAnchor="middle">12</text>

          <circle cx="315" cy="145" r="15" fill={dark ? '#064e3b' : '#d1fae5'} stroke={dark ? '#34d399' : '#059669'} strokeWidth="1.5" />
          <text x="315" y="149" fill={dark ? '#a7f3d0' : '#065f46'} fontSize="10" fontWeight="bold" textAnchor="middle">18</text>

          {/* Subtitle Annotation */}
          <text x="190" y="180" fill={dark ? '#c4b5fd' : '#4f46e5'} fontSize="10" fontWeight="600" textAnchor="middle">
            All parents (10, 5, 15) have 2 children · All leaves (2, 7, 12, 18) have 0 children
          </text>
        </svg>
      )
    },
    {
      id: 'complete',
      number: 3,
      name: 'Complete Binary Tree',
      badge: 'Filled Left to Right',
      definition: 'All levels are completely filled except possibly the last level. In the last level, all nodes are filled strictly from left to right.',
      explanation: 'Think of filling seats in a theater row by row: every row must be completely full before moving to the next, and on the current row you must sit in the leftmost available seats without skipping any spots.',
      example: 'Root 10 has children 5 and 15. Node 5 has children 2 and 7. Node 15 has left child 12. The next node would be placed at the right of 15.',
      keyPoint: 'How to recognize: Look at the last level. All nodes must be packed as far left as possible with no empty gaps on the left.',
      renderDiagram: (dark) => (
        <svg viewBox="0 0 380 200" className="w-full max-w-md h-auto">
          {/* Level 0 to 1 */}
          <line x1="190" y1="35" x2="105" y2="90" stroke={dark ? '#06b6d4' : '#0284c7'} strokeWidth="2" />
          <line x1="190" y1="35" x2="275" y2="90" stroke={dark ? '#06b6d4' : '#0284c7'} strokeWidth="2" />
          {/* Level 1 to 2 */}
          <line x1="105" y1="90" x2="65" y2="145" stroke={dark ? '#06b6d4' : '#0284c7'} strokeWidth="2" />
          <line x1="105" y1="90" x2="145" y2="145" stroke={dark ? '#06b6d4' : '#0284c7'} strokeWidth="2" />
          <line x1="275" y1="90" x2="235" y2="145" stroke={dark ? '#06b6d4' : '#0284c7'} strokeWidth="2" />

          {/* Node 10 */}
          <circle cx="190" cy="35" r="18" fill={dark ? '#0891b2' : '#0284c7'} stroke="#ffffff" strokeWidth="2" />
          <text x="190" y="39" fill="#ffffff" fontSize="12" fontWeight="bold" textAnchor="middle">10</text>

          {/* Node 5 */}
          <circle cx="105" cy="90" r="17" fill={dark ? '#164e63' : '#e0f2fe'} stroke={dark ? '#38bdf8' : '#0284c7'} strokeWidth="2" />
          <text x="105" y="94" fill={dark ? '#e0f2fe' : '#0369a1'} fontSize="11" fontWeight="bold" textAnchor="middle">5</text>

          {/* Node 15 */}
          <circle cx="275" cy="90" r="17" fill={dark ? '#164e63' : '#e0f2fe'} stroke={dark ? '#38bdf8' : '#0284c7'} strokeWidth="2" />
          <text x="275" y="94" fill={dark ? '#e0f2fe' : '#0369a1'} fontSize="11" fontWeight="bold" textAnchor="middle">15</text>

          {/* Leaves: 2, 7, 12 */}
          <circle cx="65" cy="145" r="15" fill={dark ? '#064e3b' : '#d1fae5'} stroke={dark ? '#34d399' : '#059669'} strokeWidth="1.5" />
          <text x="65" y="149" fill={dark ? '#a7f3d0' : '#065f46'} fontSize="10" fontWeight="bold" textAnchor="middle">2</text>

          <circle cx="145" cy="145" r="15" fill={dark ? '#064e3b' : '#d1fae5'} stroke={dark ? '#34d399' : '#059669'} strokeWidth="1.5" />
          <text x="145" y="149" fill={dark ? '#a7f3d0' : '#065f46'} fontSize="10" fontWeight="bold" textAnchor="middle">7</text>

          <circle cx="235" cy="145" r="15" fill={dark ? '#064e3b' : '#d1fae5'} stroke={dark ? '#34d399' : '#059669'} strokeWidth="1.5" />
          <text x="235" y="149" fill={dark ? '#a7f3d0' : '#065f46'} fontSize="10" fontWeight="bold" textAnchor="middle">12</text>

          {/* Empty slot (right child of 15) */}
          <circle
            cx="315"
            cy="145"
            r="15"
            fill="none"
            stroke={dark ? '#475569' : '#cbd5e1'}
            strokeWidth="1.5"
            strokeDasharray="3 3"
          />
          <text x="315" y="149" fill={dark ? '#64748b' : '#94a3b8'} fontSize="9" textAnchor="middle">
            next
          </text>

          {/* Bottom Callout */}
          <text x="190" y="185" fill={dark ? '#38bdf8' : '#0284c7'} fontSize="10" fontWeight="600" textAnchor="middle">
            Last level filled from left to right: [2] → [7] → [12] (no gaps on left)
          </text>
        </svg>
      )
    },
    {
      id: 'perfect',
      number: 4,
      name: 'Perfect Binary Tree',
      badge: 'Full Symmetrical Triangle',
      definition: 'A binary tree in which every internal node has exactly two children and all leaf nodes are at the same level.',
      explanation: 'Every parent has exactly two children, and every single leaf node sits on the exact same bottom level, creating a completely solid, symmetrical pyramid with no missing nodes.',
      example: 'Root 10 has children 5 and 15. Both 5 and 15 have 2 children: (2, 7) and (12, 18). All 4 leaves sit together on Level 2.',
      keyPoint: 'How to recognize: The tree forms a completely full triangle where all leaf nodes align on the exact same bottom row.',
      renderDiagram: (dark) => (
        <svg viewBox="0 0 380 200" className="w-full max-w-md h-auto">
          {/* Edges from 10 */}
          <line x1="190" y1="35" x2="105" y2="90" stroke={dark ? '#ec4899' : '#db2777'} strokeWidth="2" />
          <line x1="190" y1="35" x2="275" y2="90" stroke={dark ? '#ec4899' : '#db2777'} strokeWidth="2" />
          {/* Edges from 5 */}
          <line x1="105" y1="90" x2="65" y2="145" stroke={dark ? '#ec4899' : '#db2777'} strokeWidth="2" />
          <line x1="105" y1="90" x2="145" y2="145" stroke={dark ? '#ec4899' : '#db2777'} strokeWidth="2" />
          {/* Edges from 15 */}
          <line x1="275" y1="90" x2="235" y2="145" stroke={dark ? '#ec4899' : '#db2777'} strokeWidth="2" />
          <line x1="275" y1="90" x2="315" y2="145" stroke={dark ? '#ec4899' : '#db2777'} strokeWidth="2" />

          {/* Root 10 */}
          <circle cx="190" cy="35" r="18" fill={dark ? '#db2777' : '#be185d'} stroke="#ffffff" strokeWidth="2" />
          <text x="190" y="39" fill="#ffffff" fontSize="12" fontWeight="bold" textAnchor="middle">10</text>

          {/* Node 5 */}
          <circle cx="105" cy="90" r="17" fill={dark ? '#831843' : '#fce7f3'} stroke={dark ? '#f472b6' : '#db2777'} strokeWidth="2" />
          <text x="105" y="94" fill={dark ? '#fbcfe8' : '#831843'} fontSize="11" fontWeight="bold" textAnchor="middle">5</text>

          {/* Node 15 */}
          <circle cx="275" cy="90" r="17" fill={dark ? '#831843' : '#fce7f3'} stroke={dark ? '#f472b6' : '#db2777'} strokeWidth="2" />
          <text x="275" y="94" fill={dark ? '#fbcfe8' : '#831843'} fontSize="11" fontWeight="bold" textAnchor="middle">15</text>

          {/* Leaves: 2, 7, 12, 18 all at y=145 */}
          <circle cx="65" cy="145" r="15" fill={dark ? '#064e3b' : '#d1fae5'} stroke={dark ? '#34d399' : '#059669'} strokeWidth="1.5" />
          <text x="65" y="149" fill={dark ? '#a7f3d0' : '#065f46'} fontSize="10" fontWeight="bold" textAnchor="middle">2</text>

          <circle cx="145" cy="145" r="15" fill={dark ? '#064e3b' : '#d1fae5'} stroke={dark ? '#34d399' : '#059669'} strokeWidth="1.5" />
          <text x="145" y="149" fill={dark ? '#a7f3d0' : '#065f46'} fontSize="10" fontWeight="bold" textAnchor="middle">7</text>

          <circle cx="235" cy="145" r="15" fill={dark ? '#064e3b' : '#d1fae5'} stroke={dark ? '#34d399' : '#059669'} strokeWidth="1.5" />
          <text x="235" y="149" fill={dark ? '#a7f3d0' : '#065f46'} fontSize="10" fontWeight="bold" textAnchor="middle">12</text>

          <circle cx="315" cy="145" r="15" fill={dark ? '#064e3b' : '#d1fae5'} stroke={dark ? '#34d399' : '#059669'} strokeWidth="1.5" />
          <text x="315" y="149" fill={dark ? '#a7f3d0' : '#065f46'} fontSize="10" fontWeight="bold" textAnchor="middle">18</text>

          {/* Level line indicator */}
          <line x1="45" y1="172" x2="335" y2="172" stroke={dark ? '#f472b6' : '#db2777'} strokeWidth="1" strokeDasharray="3 3" />
          <text x="190" y="187" fill={dark ? '#f472b6' : '#db2777'} fontSize="10" fontWeight="bold" textAnchor="middle">
            All 4 leaf nodes sit at the exact same level (Level 2)
          </text>
        </svg>
      )
    },
    {
      id: 'degenerate',
      number: 5,
      name: 'Degenerate Binary Tree',
      badge: 'Single Line / Chain',
      definition: 'A tree where each parent node has only one child, so the tree looks and behaves almost like a straight line or linked list.',
      explanation: 'Because no node ever branches into two children, there is no tree hierarchy advantage. Searching this tree takes O(N) linear time, just like searching a standard linked list.',
      example: 'Root 10 connects to right child 20, which connects to right child 30, which connects to right child 40.',
      keyPoint: 'How to recognize: Every single node has only one child, making the tree look like a single diagonal line or chain.',
      renderDiagram: (dark) => (
        <svg viewBox="0 0 380 210" className="w-full max-w-md h-auto">
          {/* Diagonal connecting lines */}
          <line x1="80" y1="35" x2="150" y2="85" stroke={dark ? '#f59e0b' : '#d97706'} strokeWidth="2.5" />
          <line x1="150" y1="85" x2="220" y2="135" stroke={dark ? '#f59e0b' : '#d97706'} strokeWidth="2.5" />
          <line x1="220" y1="135" x2="290" y2="185" stroke={dark ? '#f59e0b' : '#d97706'} strokeWidth="2.5" />

          {/* Node 10 */}
          <g>
            <circle cx="80" cy="35" r="18" fill={dark ? '#d97706' : '#b45309'} stroke="#ffffff" strokeWidth="2" />
            <text x="80" y="39" fill="#ffffff" fontSize="12" fontWeight="bold" textAnchor="middle">10</text>
            <text x="80" y="14" fill={dark ? '#fcd34d' : '#92400e'} fontSize="9" fontWeight="bold" textAnchor="middle">Root (1 child)</text>
          </g>

          {/* Node 20 */}
          <g>
            <circle cx="150" cy="85" r="18" fill={dark ? '#78350f' : '#fef3c7'} stroke={dark ? '#fbbf24' : '#d97706'} strokeWidth="2" />
            <text x="150" y="89" fill={dark ? '#fef3c7' : '#78350f'} fontSize="12" fontWeight="bold" textAnchor="middle">20</text>
            <text x="150" y="64" fill={dark ? '#fcd34d' : '#92400e'} fontSize="9" fontWeight="bold" textAnchor="middle">1 child</text>
          </g>

          {/* Node 30 */}
          <g>
            <circle cx="220" cy="135" r="18" fill={dark ? '#78350f' : '#fef3c7'} stroke={dark ? '#fbbf24' : '#d97706'} strokeWidth="2" />
            <text x="220" y="139" fill={dark ? '#fef3c7' : '#78350f'} fontSize="12" fontWeight="bold" textAnchor="middle">30</text>
            <text x="220" y="114" fill={dark ? '#fcd34d' : '#92400e'} fontSize="9" fontWeight="bold" textAnchor="middle">1 child</text>
          </g>

          {/* Node 40 (Leaf) */}
          <g>
            <circle cx="290" cy="185" r="18" fill={dark ? '#064e3b' : '#d1fae5'} stroke={dark ? '#34d399' : '#059669'} strokeWidth="2" />
            <text x="290" y="189" fill={dark ? '#a7f3d0' : '#065f46'} fontSize="12" fontWeight="bold" textAnchor="middle">40</text>
            <text x="290" y="206" fill={dark ? '#34d399' : '#059669'} fontSize="9" fontWeight="bold" textAnchor="middle">Leaf (End)</text>
          </g>
        </svg>
      )
    },
    {
      id: 'bst',
      number: 6,
      name: 'Binary Search Tree (BST)',
      badge: 'Left < Root < Right',
      definition: 'A binary tree where smaller values go to the left and larger values go to the right for every single node.',
      explanation: 'For every node in a BST: all values in its left subtree are strictly smaller than the node value, and all values in its right subtree are strictly larger. This order makes searching take O(log N) time on average.',
      example: 'Root 50 has left child 30 (which has children 20 and 40) and right child 70 (which has children 60 and 80).',
      keyPoint: 'How to recognize: Check if left subtree values < node value < right subtree values at every point in the tree.',
      renderDiagram: (dark) => (
        <svg viewBox="0 0 380 200" className="w-full max-w-md h-auto">
          {/* Subtree boundaries */}
          <rect
            x="35"
            y="75"
            width="135"
            height="105"
            rx="12"
            fill={dark ? '#064e3b' : '#ecfdf5'}
            fillOpacity="0.25"
            stroke="#10b981"
            strokeWidth="1.5"
            strokeDasharray="3 3"
          />
          <text x="102" y="68" fill="#10b981" fontSize="10" fontFamily="monospace" fontWeight="bold" textAnchor="middle">
            &lt; 50 (LEFT SUBTREE)
          </text>

          <rect
            x="210"
            y="75"
            width="135"
            height="105"
            rx="12"
            fill={dark ? '#1e3a8a' : '#eff6ff'}
            fillOpacity="0.25"
            stroke="#3b82f6"
            strokeWidth="1.5"
            strokeDasharray="3 3"
          />
          <text x="278" y="68" fill="#3b82f6" fontSize="10" fontFamily="monospace" fontWeight="bold" textAnchor="middle">
            &gt; 50 (RIGHT SUBTREE)
          </text>

          {/* Edges from 50 */}
          <line x1="190" y1="35" x2="105" y2="90" stroke="#10b981" strokeWidth="2" />
          <line x1="190" y1="35" x2="275" y2="90" stroke="#3b82f6" strokeWidth="2" />
          {/* Edges from 30 */}
          <line x1="105" y1="90" x2="65" y2="145" stroke="#10b981" strokeWidth="2" />
          <line x1="105" y1="90" x2="145" y2="145" stroke="#10b981" strokeWidth="2" />
          {/* Edges from 70 */}
          <line x1="275" y1="90" x2="235" y2="145" stroke="#3b82f6" strokeWidth="2" />
          <line x1="275" y1="90" x2="315" y2="145" stroke="#3b82f6" strokeWidth="2" />

          {/* Root 50 */}
          <circle cx="190" cy="35" r="18" fill={dark ? '#059669' : '#10b981'} stroke="#ffffff" strokeWidth="2" />
          <text x="190" y="39" fill="#ffffff" fontSize="12" fontWeight="bold" textAnchor="middle">50</text>

          {/* Left child 30 */}
          <circle cx="105" cy="90" r="16" fill={dark ? '#064e3b' : '#d1fae5'} stroke="#10b981" strokeWidth="2" />
          <text x="105" y="94" fill={dark ? '#ffffff' : '#065f46'} fontSize="11" fontWeight="bold" textAnchor="middle">30</text>

          {/* Right child 70 */}
          <circle cx="275" cy="90" r="16" fill={dark ? '#1e3a8a' : '#dbeafe'} stroke="#3b82f6" strokeWidth="2" />
          <text x="275" y="94" fill={dark ? '#ffffff' : '#1e3a8a'} fontSize="11" fontWeight="bold" textAnchor="middle">70</text>

          {/* Leaves: 20, 40, 60, 80 */}
          <circle cx="65" cy="145" r="14" fill={dark ? '#022c22' : '#a7f3d0'} stroke="#10b981" strokeWidth="1.5" />
          <text x="65" y="149" fill={dark ? '#a7f3d0' : '#065f46'} fontSize="10" fontWeight="bold" textAnchor="middle">20</text>

          <circle cx="145" cy="145" r="14" fill={dark ? '#022c22' : '#a7f3d0'} stroke="#10b981" strokeWidth="1.5" />
          <text x="145" y="149" fill={dark ? '#a7f3d0' : '#065f46'} fontSize="10" fontWeight="bold" textAnchor="middle">40</text>

          <circle cx="235" cy="145" r="14" fill={dark ? '#172554' : '#bfdbfe'} stroke="#3b82f6" strokeWidth="1.5" />
          <text x="235" y="149" fill={dark ? '#bfdbfe' : '#1e3a8a'} fontSize="10" fontWeight="bold" textAnchor="middle">60</text>

          <circle cx="315" cy="145" r="14" fill={dark ? '#172554' : '#bfdbfe'} stroke="#3b82f6" strokeWidth="1.5" />
          <text x="315" y="149" fill={dark ? '#bfdbfe' : '#1e3a8a'} fontSize="10" fontWeight="bold" textAnchor="middle">80</text>

          <text x="190" y="190" fill={dark ? '#a7f3d0' : '#047857'} fontSize="10" fontWeight="600" textAnchor="middle">
            (20, 30, 40) &lt; 50 &lt; (60, 70, 80)
          </text>
        </svg>
      )
    }
  ];

  return (
    <div className="space-y-6">
      {types.map((type) => (
        <div
          key={type.id}
          id={`tree-type-card-${type.id}`}
          className={`p-6 sm:p-7 rounded-3xl border transition-all ${
            isDarkMode
              ? 'bg-[#0e1424] border-violet-900/40 text-slate-100 shadow-xl shadow-violet-950/20'
              : 'bg-white border-slate-200 text-slate-900 shadow-sm'
          }`}
        >
          {/* Header & Numbering */}
          <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
            <div className="flex items-center gap-3">
              <span className="w-7 h-7 rounded-xl bg-violet-600/20 border border-violet-500/30 text-violet-400 font-mono font-bold text-xs flex items-center justify-center">
                0{type.number}
              </span>
              <h2 className="text-lg sm:text-xl font-bold tracking-tight">
                {type.number}. {type.name}
              </h2>
            </div>

            <span
              className={`text-[11px] font-mono font-semibold px-2.5 py-0.5 rounded-full border ${
                isDarkMode
                  ? 'bg-[#151c2e] border-violet-800/40 text-violet-300'
                  : 'bg-indigo-50 border-indigo-200 text-indigo-700'
              }`}
            >
              {type.badge}
            </span>
          </div>

          {/* 1. Definition */}
          <div className="mb-4">
            <div className="flex items-center gap-2 mb-1.5">
              <span className="w-2 h-2 rounded-full bg-violet-400" />
              <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-violet-400">
                Definition
              </span>
            </div>
            <blockquote
              className={`p-3.5 sm:p-4 rounded-2xl border text-xs sm:text-sm font-medium leading-relaxed ${
                isDarkMode
                  ? 'bg-[#090d18] border-violet-950/80 text-violet-100'
                  : 'bg-violet-50/60 border-violet-200 text-violet-950'
              }`}
            >
              &ldquo;{type.definition}&rdquo;
            </blockquote>
          </div>

          {/* 2. Simple Explanation */}
          <div className="mb-4">
            <p className="text-xs sm:text-sm leading-relaxed opacity-90">
              {type.explanation}
            </p>
          </div>

          {/* 3. Example */}
          <div className="mb-4">
            <div
              className={`p-3.5 rounded-2xl border text-xs sm:text-sm flex items-start gap-2.5 ${
                isDarkMode
                  ? 'bg-[#121929] border-violet-950/70 text-slate-200'
                  : 'bg-slate-50 border-slate-200 text-slate-800'
              }`}
            >
              <span className="font-bold text-violet-400 shrink-0">Example:</span>
              <span className="leading-relaxed opacity-95">{type.example}</span>
            </div>
          </div>

          {/* 4. Architecture Diagram */}
          <div className="my-5">
            {/* Label above diagram */}
            <div className="flex items-center gap-1.5 mb-2">
              <Network className="w-3.5 h-3.5 text-violet-400" />
              <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-violet-400">
                Architecture Diagram
              </span>
            </div>

            {/* Visual Canvas */}
            <div
              className={`p-4 sm:p-5 rounded-2xl border flex flex-col items-center justify-center overflow-x-auto ${
                isDarkMode
                  ? 'bg-[#070a12] border-violet-950/80'
                  : 'bg-slate-50 border-slate-200'
              }`}
            >
              {type.renderDiagram(isDarkMode)}
            </div>
          </div>

          {/* 5. Key Point */}
          <div>
            <div
              className={`p-3.5 rounded-2xl border text-xs flex items-start gap-2.5 ${
                isDarkMode
                  ? 'bg-amber-950/20 border-amber-500/30 text-amber-200'
                  : 'bg-amber-50 border-amber-200 text-amber-900'
              }`}
            >
              <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold text-amber-400 mb-0.5">Key Point</div>
                <div className="leading-relaxed opacity-95">{type.keyPoint}</div>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
