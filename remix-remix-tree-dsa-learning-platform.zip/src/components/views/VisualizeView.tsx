import React, { useState } from 'react';
import { TraversalVisualizer } from '../visualizer/TraversalVisualizer';
import { BSTVisualizer } from '../visualizer/BSTVisualizer';
import { BasicsVisualizer } from '../visualizer/BasicsVisualizer';
import { TerminologyVisualizer } from '../visualizer/TerminologyVisualizer';
import { TreeTypesVisualizer } from '../visualizer/TreeTypesVisualizer';
import { BinaryTreeVisualizer } from '../visualizer/BinaryTreeVisualizer';
import {
  Eye,
  GitBranch,
  Layers,
  Terminal,
  Activity,
  Sparkles
} from 'lucide-react';

interface VisualizeViewProps {
  isDarkMode: boolean;
}

type VisualizerTab = 'traversals' | 'bst' | 'terminology' | 'types' | 'binary' | 'basics';

export const VisualizeView: React.FC<VisualizeViewProps> = ({ isDarkMode }) => {
  const [activeTab, setActiveTab] = useState<VisualizerTab>('traversals');

  const tabs: { id: VisualizerTab; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'traversals', label: 'Tree Traversals (Pre, In, Post, BFS)', icon: Activity },
    { id: 'bst', label: 'BST Insert / Search / Delete', icon: Terminal },
    { id: 'terminology', label: '13 Tree Terminologies', icon: Layers },
    { id: 'types', label: '7 Tree Classifications', icon: GitBranch },
    { id: 'binary', label: 'Binary Tree & Array Layout', icon: Sparkles },
    { id: 'basics', label: 'Hierarchy & N-1 Edges', icon: Eye }
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-6 py-2">
      {/* Header */}
      <div
        className={`p-6 sm:p-8 rounded-3xl border transition-all duration-200 ${
          isDarkMode
            ? 'bg-[#0e1424] border-violet-900/40 text-slate-100 shadow-xl shadow-violet-950/30'
            : 'bg-white border-slate-200 text-slate-900 shadow-sm'
        }`}
      >
        <div className="flex items-center gap-2 text-xs font-bold font-mono uppercase tracking-wider text-violet-400 mb-2">
          <Eye className="w-4 h-4" />
          <span>Interactive Visualization Workspace</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
          Tree Algorithms & Structure Visualizer
        </h1>
        <p className="text-xs sm:text-sm mt-1.5 opacity-80 leading-relaxed max-w-2xl">
          Execute step-by-step tree algorithms with full playback controls (Play, Pause, Restart, Speed 1x/1.5x/2x), 
          node highlight animations, call stack monitoring, and dynamic BST updates.
        </p>

        {/* Visualizer Category Switcher */}
        <div className="flex flex-wrap gap-2 mt-6 pt-5 border-t border-violet-950/60">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;

            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  isActive
                    ? isDarkMode
                      ? 'bg-violet-600 text-white shadow-lg shadow-violet-900/50 ring-1 ring-violet-400/40'
                      : 'bg-indigo-600 text-white shadow-md shadow-indigo-200'
                    : isDarkMode
                    ? 'bg-[#141c2e] hover:bg-[#1a243c] text-slate-300 border border-violet-950/70'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Visualizer Container */}
      <div
        className={`p-6 rounded-3xl border transition-all duration-300 ${
          isDarkMode
            ? 'bg-[#0e1424] border-violet-900/40 text-slate-100'
            : 'bg-white border-slate-200 text-slate-900 shadow-sm'
        }`}
      >
        {activeTab === 'traversals' && <TraversalVisualizer isDarkMode={isDarkMode} />}
        {activeTab === 'bst' && <BSTVisualizer isDarkMode={isDarkMode} />}
        {activeTab === 'terminology' && <TerminologyVisualizer isDarkMode={isDarkMode} />}
        {activeTab === 'types' && <TreeTypesVisualizer isDarkMode={isDarkMode} />}
        {activeTab === 'binary' && <BinaryTreeVisualizer isDarkMode={isDarkMode} />}
        {activeTab === 'basics' && <BasicsVisualizer isDarkMode={isDarkMode} />}
      </div>
    </div>
  );
};
