import React, { useState } from 'react';
import { NavItem } from '../types';
import {
  Menu,
  GitBranch,
  Sun,
  Moon,
  Volume2,
  VolumeX,
  RotateCcw
} from 'lucide-react';

interface TopHeaderProps {
  currentNav: NavItem;
  onToggleSidebar: () => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
  onResetPage?: () => void;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  currentNav,
  onToggleSidebar,
  isDarkMode,
  onToggleTheme,
  onResetPage
}) => {
  const [isSoundOn, setIsSoundOn] = useState<boolean>(true);

  const getPageTitle = (nav: NavItem): string => {
    switch (nav) {
      case 'home':
        return 'Overview';
      case 'learn':
        return 'Learn';
      case 'visualize':
        return 'Visualize';
      case 'game':
        return 'Game';
      case 'quiz':
        return 'Quiz';
      case 'progress':
        return 'Progress';
      default:
        return 'Overview';
    }
  };

  const handleToggleSound = () => {
    setIsSoundOn((prev) => !prev);
  };

  return (
    <header
      className={`h-16 px-4 sm:px-6 flex items-center justify-between border-b sticky top-0 z-30 transition-colors duration-200 backdrop-blur-md ${
        isDarkMode
          ? 'bg-[#090d16]/90 border-violet-950/60 text-slate-100'
          : 'bg-white/90 border-slate-200 text-slate-900'
      }`}
    >
      {/* Left side: Hamburger menu button + Project Icon & Name + Current Page Badge */}
      <div className="flex items-center gap-3">
        <button
          id="header-hamburger-btn"
          onClick={onToggleSidebar}
          title="Toggle Navigation Sidebar (☰)"
          className={`p-2 rounded-xl transition-all cursor-pointer ${
            isDarkMode
              ? 'hover:bg-[#151c2e] text-slate-300 hover:text-white'
              : 'hover:bg-slate-100 text-slate-600 hover:text-slate-900'
          }`}
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5">
          <div
            className={`w-8 h-8 rounded-xl flex items-center justify-center text-white shrink-0 shadow-md ${
              isDarkMode ? 'bg-violet-600 shadow-violet-900/40' : 'bg-indigo-600 shadow-indigo-200'
            }`}
          >
            <GitBranch className="w-4 h-4" />
          </div>
          <div className="hidden sm:flex flex-col">
            <span
              className={`font-extrabold text-xs tracking-tight uppercase leading-tight ${
                isDarkMode ? 'text-violet-300' : 'text-indigo-900'
              }`}
            >
              Tree DSA
            </span>
            <span className="text-[10px] opacity-60 font-medium">Interactive Learning</span>
          </div>
        </div>

        {/* Divider */}
        <div
          className={`h-4 w-px mx-1 hidden sm:block ${
            isDarkMode ? 'bg-violet-900/40' : 'bg-slate-200'
          }`}
        />

        {/* Current Page Name Badge */}
        <div
          className={`px-3 py-1 rounded-full text-xs font-bold tracking-wide flex items-center gap-1.5 ${
            isDarkMode
              ? 'bg-violet-950/60 text-violet-300 border border-violet-800/40'
              : 'bg-indigo-50 text-indigo-700 border border-indigo-200/60'
          }`}
        >
          <span
            className={`w-1.5 h-1.5 rounded-full ${
              isDarkMode ? 'bg-violet-400 animate-pulse' : 'bg-indigo-600 animate-pulse'
            }`}
          />
          <span>{getPageTitle(currentNav)}</span>
        </div>
      </div>

      {/* Right side: Sound toggle, Reset control, Theme toggle */}
      <div className="flex items-center gap-1.5 sm:gap-2">
        {/* Audio / Sound feedback toggle */}
        <button
          onClick={handleToggleSound}
          title={isSoundOn ? 'Sound Effects Enabled' : 'Sound Effects Muted'}
          className={`p-2 rounded-xl transition-all cursor-pointer ${
            isDarkMode
              ? 'hover:bg-[#151c2e] text-slate-300 hover:text-white'
              : 'hover:bg-slate-100 text-slate-600 hover:text-slate-900'
          }`}
        >
          {isSoundOn ? (
            <Volume2 className="w-4 h-4 text-violet-400" />
          ) : (
            <VolumeX className="w-4 h-4 opacity-40" />
          )}
        </button>

        {/* Reset / Reload page control */}
        <button
          onClick={onResetPage}
          title="Reset View / State"
          className={`p-2 rounded-xl transition-all cursor-pointer ${
            isDarkMode
              ? 'hover:bg-[#151c2e] text-slate-300 hover:text-white'
              : 'hover:bg-slate-100 text-slate-600 hover:text-slate-900'
          }`}
        >
          <RotateCcw className="w-4 h-4 text-slate-400 hover:rotate-180 transition-transform duration-300" />
        </button>

        {/* Theme toggle */}
        <button
          onClick={onToggleTheme}
          title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          className={`p-2 rounded-xl transition-all cursor-pointer ${
            isDarkMode
              ? 'bg-[#121929] hover:bg-[#1a233a] text-amber-300 border border-violet-950/70'
              : 'bg-slate-100 hover:bg-slate-200 text-indigo-600 border border-slate-200'
          }`}
        >
          {isDarkMode ? (
            <Sun className="w-4 h-4 text-amber-400" />
          ) : (
            <Moon className="w-4 h-4 text-indigo-600" />
          )}
        </button>
      </div>
    </header>
  );
};
