import React, { useState } from 'react';
import { NavItem, TopicId } from './types';
import { NavigationSidebar } from './components/NavigationSidebar';
import { TopHeader } from './components/TopHeader';
import { HomeView } from './components/views/HomeView';
import { LearnView } from './components/views/LearnView';
import { VisualizeView } from './components/views/VisualizeView';
import { QuizView } from './components/views/QuizView';
import { GameView } from './components/views/GameView';
import { ProgressView } from './components/views/ProgressView';

export default function App() {
  const [currentNav, setCurrentNav] = useState<NavItem>('home');
  const [currentTopicId, setCurrentTopicId] = useState<TopicId>('basics');
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(true);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(true); // Violet/purple dark theme default

  // Completed topics & quiz progress tracking in localStorage (defaults to empty array 0/6)
  const [completedTopics, setCompletedTopics] = useState<TopicId[]>(() => {
    try {
      const saved = localStorage.getItem('tree_dsa_completed_topics');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [quizScore, setQuizScore] = useState<{ score: number; total: number } | null>(() => {
    try {
      const saved = localStorage.getItem('tree_dsa_quiz_score');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const handleMarkTopicCompleted = (topicId: TopicId) => {
    setCompletedTopics((prev) => {
      let next: TopicId[];
      if (prev.includes(topicId)) {
        next = prev.filter((id) => id !== topicId);
      } else {
        next = [...prev, topicId];
      }
      try {
        localStorage.setItem('tree_dsa_completed_topics', JSON.stringify(next));
      } catch {}
      return next;
    });
  };

  const handleUpdateQuizScore = (score: number, total: number) => {
    const data = { score, total };
    setQuizScore(data);
    try {
      localStorage.setItem('tree_dsa_quiz_score', JSON.stringify(data));
    } catch {}
  };

  const handleResetProgress = () => {
    setCompletedTopics([]);
    setQuizScore(null);
    try {
      localStorage.removeItem('tree_dsa_completed_topics');
      localStorage.removeItem('tree_dsa_quiz_score');
    } catch {}
  };

  const handleNavigate = (nav: NavItem, topicId?: TopicId) => {
    setCurrentNav(nav);
    if (topicId) {
      setCurrentTopicId(topicId);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleToggleSidebar = () => {
    setIsSidebarOpen((prev) => !prev);
  };

  return (
    <div
      className={`min-h-screen transition-colors duration-300 ${
        isDarkMode
          ? 'bg-[#080c16] text-slate-100 selection:bg-violet-600 selection:text-white'
          : 'bg-slate-50 text-slate-900 selection:bg-indigo-600 selection:text-white'
      }`}
    >
      {/* Left-Side Navigation Sidebar */}
      <NavigationSidebar
        currentNav={currentNav}
        onSelectNav={(nav) => handleNavigate(nav)}
        isOpen={isSidebarOpen}
        onToggleOpen={handleToggleSidebar}
        onClose={() => setIsSidebarOpen(false)}
        isDarkMode={isDarkMode}
        onToggleTheme={() => setIsDarkMode(!isDarkMode)}
        completedTopics={completedTopics}
        quizScore={quizScore}
      />

      {/* Main Content Area (Expands to full width when sidebar is closed) */}
      <div
        className={`transition-all duration-300 flex flex-col min-h-screen ${
          isSidebarOpen ? 'md:ml-64' : 'ml-0'
        }`}
      >
        {/* Top Header Bar */}
        <TopHeader
          currentNav={currentNav}
          onToggleSidebar={handleToggleSidebar}
          isDarkMode={isDarkMode}
          onToggleTheme={() => setIsDarkMode(!isDarkMode)}
          onResetPage={() => handleNavigate('home')}
        />

        {/* View Content Renderer */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8">
          {currentNav === 'home' && (
            <HomeView
              onNavigate={handleNavigate}
              isDarkMode={isDarkMode}
            />
          )}

          {currentNav === 'learn' && (
            <LearnView
              currentTopicId={currentTopicId}
              onSelectTopic={(topicId) => {
                setCurrentTopicId(topicId);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              isDarkMode={isDarkMode}
              completedTopics={completedTopics}
              onMarkTopicCompleted={handleMarkTopicCompleted}
            />
          )}

          {currentNav === 'visualize' && (
            <VisualizeView isDarkMode={isDarkMode} />
          )}

          {currentNav === 'game' && (
            <GameView isDarkMode={isDarkMode} />
          )}

          {currentNav === 'quiz' && (
            <QuizView
              isDarkMode={isDarkMode}
              onUpdateQuizScore={handleUpdateQuizScore}
            />
          )}

          {currentNav === 'progress' && (
            <ProgressView
              completedTopics={completedTopics}
              quizScore={quizScore}
              onNavigate={handleNavigate}
              onResetProgress={handleResetProgress}
              isDarkMode={isDarkMode}
            />
          )}
        </main>
      </div>
    </div>
  );
}
